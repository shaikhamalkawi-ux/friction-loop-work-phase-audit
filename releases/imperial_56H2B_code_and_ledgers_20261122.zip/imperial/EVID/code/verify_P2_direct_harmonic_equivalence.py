#!/usr/bin/env python3
"""Operator identity: work after least-squares harmonic reconstruction equals
linear weighted sum of observed forces. This is an algebra check, not a novel
estimator or a physical-energy certificate.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np,pandas as pd
from scipy.io import loadmat

def work_weights(x):return .5*(np.roll(x,-1)-np.roll(x,1))
def mat(pos,k):
 w=2*np.pi*np.asarray(pos)/600
 return np.column_stack([np.ones(len(w))]+[term for j in range(1,k+1) for term in (np.sin(j*w),np.cos(j*w))])
def samp(q,phase):
 tau=600*(np.arange(q)+phase/16)/q
 return np.sort(np.floor(tau+.5-1e-12).astype(int)%600)

def main():
 arg=argparse.ArgumentParser();arg.add_argument('--source-dir',type=Path,required=True);arg.add_argument('--derived-dir',type=Path,required=True);arg.add_argument('--out',type=Path,required=True);a=arg.parse_args();a.out.mkdir(exist_ok=True,parents=True)
 reg=pd.read_csv(a.derived_dir/'docs/LOCKED_27_SOURCE_SHA256.csv')
 old=pd.read_csv(a.derived_dir/'baseline/P2_Imperial27_AllBudgets_Phases.csv')
 old=old[old.method.isin(['H1','H3'])].set_index(['IC','q','phase','method'])
 results=[];mx=0.
 for rec in reg.itertuples():
  p=a.source_dir/f'IC{rec.IC}_cycle{rec.cycle_id}.mat';assert hashlib.sha256(p.read_bytes()).hexdigest()==rec.sha256
  x,f=loadmat(p)['hyst'].T;c=work_weights(x);Wref=float(c@f)
  for q in [16,32,64,128]:
   for phase in range(16):
    obs=samp(q,phase)
    for model,k in [('H1',1),('H3',3)]:
     A=mat(obs,k);B=mat(np.arange(600),k)
     z=B.T@c
     co=np.linalg.lstsq(A,f[obs],rcond=None)[0]
     reconstructed=float(z@co)
     aq=np.linalg.pinv(A).T@z
     work_only=float(aq@f[obs])
     archived=float(old.loc[(rec.IC,q,phase,model),'Wpred_native']);err=max(abs(reconstructed-archived),abs(work_only-archived),abs(work_only-reconstructed));mx=max(mx,err)
     results.append(dict(IC=rec.IC,q=q,phase=phase,model=model,rank=np.linalg.matrix_rank(A),basis_columns=A.shape[1],Wref_native=Wref,W_from_reconstruction=reconstructed,W_direct_observed_weighted=work_only,W_archived=archived,max_abs_parity_error=err,observation_weights_l2=float(np.linalg.norm(aq))))
 df=pd.DataFrame(results);df.to_csv(a.out/'P2_DirectHarmonic_FunctionalOperatorParity.csv',index=False,float_format='%.17g')
 summary=dict(n_results=len(results),max_abs_parity_error=mx,n_source_conditions=27,n_phase_masks=16,n_budgets=4,models=['H1','H3'],algebra='W=c(x)^T B (A^+) y_observed = [(A^+)^T B^T c(x)]^T y_observed',novelty_claim='none; established linear algebra equivalence')
 (a.out/'P2_DirectHarmonic_FunctionalParity_Summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(summary)
 if mx>1e-8 or len(df)!=27*4*16*2:raise AssertionError('Direct-harmonic parity or coverage failure')

if __name__=='__main__':main()
