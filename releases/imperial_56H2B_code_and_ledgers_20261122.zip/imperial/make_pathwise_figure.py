from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
plt.rcParams.update({'pdf.fonttype':42,'ps.fonttype':42,'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
d=pd.read_csv(R/'results/SD16_PoliTO_SixPairs_AffinePhaseErrors.csv')
ref=pd.read_csv(R/'results/SD16_PoliTO_SixPairs_Pathwise_WinnerAudit.csv')
fig,axs=plt.subplots(1,2,figsize=(10,3.6))
for ax,(cas,stage,q) in zip(axs,[('AF10',945000,32),('AF19',945000,64)]):
 t=d[(d.case==cas)&(d.stage==stage)&(d.q==q)];meta=ref[(ref.case==cas)&(ref.stage==stage)&(ref.q==q)].iloc[0]
 z=np.linspace(0,1,401);denom=np.abs(meta.W_raw+z*(meta.W_processed-meta.W_raw))
 for m in ['Periodic PCHIP','Periodic cubic','H1','H3','Periodic linear']:
  sub=t[t.method==m];a=sub.signed_error_raw.to_numpy();b=sub.signed_error_slope.to_numpy()
  y=100*np.max(np.abs(a[:,None]+b[:,None]*z),axis=0)/denom
  ax.plot(z,y,lw=1.6 if m in ['Periodic PCHIP','Periodic cubic'] else .8,alpha=1 if m in ['Periodic PCHIP','Periodic cubic'] else .5,label=m)
 ax.set_title(f'{cas}, stored cycle {stage}, q={q}')
 ax.set_xlabel(r'Processing path $\lambda$: raw $\to$ processed')
 ax.set_ylabel('Worst-of-16-phase work error (%)')
 # Derive transition from segments table exactly, not by line-grid estimation
 seg=pd.read_csv(R/'results/SD16_PoliTO_SixPairs_WinnerSegments.csv');part=seg[(seg.case==cas)&(seg.stage==stage)&(seg.q==q)]
 if len(part)>1:ax.axvline(float(part.iloc[0].end),ls='--',color='black',lw=.8)
axs[1].legend(loc='upper left',fontsize=7,frameon=False)
fig.suptitle('Two observed winner transitions under fixed force reconstructions',fontsize=11)
fig.tight_layout();fig.savefig(R/'figures/P2_SD16_PoliTO_PairedPathwiseTransitions.pdf')
print('FIG READY')
