#!/usr/bin/env python3
"""H2 SD16: exact finite family of periodic index phase masks, 600 samples.
Audit is retrospective on public provider-processed Imperial MAT traces, not
physical timing jitter or a new prospective instrument experiment. Reproduce
archived phase-16 results BEFORE reporting phase-75 results.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
from fractions import Fraction
import hashlib,json,sys
import numpy as np,pandas as pd
from scipy.io import loadmat
from scipy.interpolate import PchipInterpolator
ROOT=Path(__file__).resolve().parent
from scipy.interpolate import CubicSpline
class Frozen:
    METHODS_P2=('H1','H3','Periodic linear','Periodic PCHIP','Periodic cubic')
    @staticmethod
    def sample(q,phase):
        t=600*(np.arange(q)+phase/16)/q
        return np.sort((np.floor(t+.5-1e-12).astype(int)%600))
    @staticmethod
    def predict_force(method,positions,sparse,target):
        tau=np.asarray(positions,float);y=np.asarray(sparse,float)
        if method in ('H1','H3'):
            k=1 if method=='H1' else 3
            w=2*np.pi*tau/600;W=2*np.pi*np.asarray(target)/600
            A=np.column_stack([np.ones(len(w))]+[z for j in range(1,k+1) for z in (np.sin(j*w),np.cos(j*w))])
            B=np.column_stack([np.ones(len(W))]+[z for j in range(1,k+1) for z in (np.sin(j*W),np.cos(j*W))])
            return B@np.linalg.lstsq(A,y,rcond=None)[0]
        if method=='Periodic linear':
            return np.interp(target,np.r_[tau-600,tau,tau+600],np.tile(y,3))
        if method=='Periodic PCHIP':
            return PchipInterpolator(np.r_[tau-600,tau,tau+600],np.tile(y,3),extrapolate=False)(target)
        if method=='Periodic cubic':
            sp=CubicSpline(np.r_[tau,tau[0]+600],np.r_[y,y[0]],bc_type='periodic',extrapolate='periodic')
            return sp(((np.asarray(target)-tau[0])%600)+tau[0])
        raise KeyError(method)
frozen=Frozen()
N=600
BUDGETS=(16,32,64,128)
METHODS=(*frozen.METHODS_P2,'Nearest observed force')

def phase_masks(q):
    # Rounded sample positions only change at these exact rational phases.
    boundaries=sorted({Fraction((2*j+1)*q,2*N)%1 for j in range(N)})
    assert len(boundaries)==N//np.gcd(N,q)==75
    midpoints=[(boundaries[j]+(boundaries[j+1] if j<len(boundaries)-1 else boundaries[0]+1))/2%1 for j in range(len(boundaries))]
    def mask(alpha):
        # no floating-point reliance near a half-integer: exact half-up with tie to lower.
        o=[]
        for k in range(q):
            y=(k+alpha)*Fraction(N,q)
            o.append(int((y+Fraction(1,2)).__ceil__()-1 if (y%1)==Fraction(1,2) else (y+Fraction(1,2)).__floor__())%N)
        return tuple(sorted(o))
    unique={mask(a):a for a in midpoints}
    assert len(unique)==75
    old={mask(Fraction(p,16)) for p in range(16)}
    assert len(old)==16 and old.issubset(unique)
    return [{'q':q,'mask_id':j,'phase_numerator':a.numerator,'phase_denominator':a.denominator,'alpha':float(a),'indices':m,'legacy16_mask':m in old} for j,(m,a) in enumerate(sorted(unique.items()))]

def nearest_predict(idx,f):
    t=np.arange(N)[:,None]
    d=np.abs(t-idx[None,:]);d=np.minimum(d,N-d)
    where=np.argmin(d,axis=1)
    return f[idx[where]]

def run():
    out=ROOT/'results';out.mkdir(exist_ok=True)
    reg=pd.read_csv(ROOT/'EVID/docs/LOCKED_27_SOURCE_SHA256.csv')
    old=pd.read_csv(ROOT/'EVID/baseline/P2_Imperial27_AllBudgets_Phases.csv')
    old=old.set_index(['IC','q','phase','method'])
    assert len(old)==8640
    masks={q:phase_masks(q) for q in BUDGETS}
    pd.DataFrame([{k:v for k,v in d.items() if k!='indices'}|{'indices':','.join(map(str,d['indices']))} for q in BUDGETS for d in masks[q]]).to_csv(out/'SD16_Exact75Mask_Register.csv',index=False)
    rows=[];old_delta=[];rank=[];absolute=[]
    for z in reg.itertuples():
        p=ROOT/'private_inputs'/f'IC{z.IC}_cycle{z.cycle_id}.mat';assert p.stat().st_size==z.size and hashlib.sha256(p.read_bytes()).hexdigest()==z.sha256
        xy=loadmat(p)['hyst'];assert xy.shape==(N,2) and np.isfinite(xy).all()
        x,f=xy.T;c=.5*(np.roll(x,-1)-np.roll(x,1));ref=float(c@f);assert ref!=0
        cohort=old.loc[(z.IC,16,0,'H1'),'cohort']
        for q in BUDGETS:
            for d in masks[q]:
                idx=np.asarray(d['indices'],dtype=int);pred={m:None for m in METHODS}
                for m in METHODS:
                    if m=='Nearest observed force': yhat=nearest_predict(idx,f)
                    else: yhat=frozen.predict_force(m,idx,f[idx],np.arange(N))
                    work=float(c@yhat);err=float(abs(work-ref));pct=float(100*err/abs(ref))
                    rows.append({'IC':int(z.IC),'cohort':cohort,'cycle_id':int(z.cycle_id),'q':q,'mask_id':d['mask_id'],'phase_alpha':d['alpha'],'method':m,'Wref_native':ref,'Wpred_native':work,'E_abs_native':err,'E_work_pct':pct,'legacy16_mask':d['legacy16_mask']})
                # Match every legacy 16 phase against its source mask, even if midpoint alpha differs.
            for ph in range(16):
                old_idx=tuple(frozen.sample(q,ph))
                d=next(e for e in masks[q] if e['indices']==old_idx)
                for m in frozen.METHODS_P2:
                    published=old.loc[(z.IC,q,ph,m)]
                    hit=rows[-75*len(METHODS)+d['mask_id']*len(METHODS):] if False else None
                    # Pooled list order has q last 75 * 6 rows; match exact d id.
                    trial=next(r for r in rows[-75*len(METHODS):] if r['mask_id']==d['mask_id'] and r['method']==m)
                    dw=abs(float(published.Wpred_native)-trial['Wpred_native'])
                    de=abs(float(published.E_work_pct)-trial['E_work_pct'])
                    if dw>1e-8 or de>1e-7:raise ValueError(f'SD11 archived score parity failed IC{z.IC},q{q},phase{ph},{m}:dw{dw} de{de}')
                    old_delta.append({'IC':int(z.IC),'q':q,'phase':ph,'method':m,'abs_diff_W':dw,'abs_diff_pct':de})
        print('SOURCE_75_PASS',z.IC,flush=True)
    frame=pd.DataFrame(rows);assert len(frame)==27*4*75*6==48600
    frame.to_csv(out/'SD16_Imperial27_Exhaustive75_AllScores.csv',index=False,float_format='%.17g')
    olddelta=pd.DataFrame(old_delta);olddelta.to_csv(out/'SD16_Archived16_Parity.csv',index=False,float_format='%.17g')
    case=frame.groupby(['IC','cohort','q','method'],as_index=False).agg(worst_pct=('E_work_pct','max'),worst_abs=('E_abs_native','max'),median_phase_pct=('E_work_pct','median'),best_phase_pct=('E_work_pct','min'))
    # exact phase event support bound vs previously stored 16 masks
    oldframe=frame[frame.legacy16_mask]
    case16=oldframe.groupby(['IC','q','method'],as_index=False).agg(worst16_pct=('E_work_pct','max'),worst16_abs=('E_abs_native','max'))
    case=case.merge(case16,on=['IC','q','method'],validate='one_to_one')
    case['worst75_minus16_pct']=case.worst_pct-case.worst16_pct
    assert (case.worst75_minus16_pct>=-1e-9).all()
    case.to_csv(out/'SD16_Imperial27_CaseWorst75_vs16.csv',index=False,float_format='%.17g')
    summary=case.groupby(['q','method'],as_index=False).agg(n=('IC','size'),mean_worst16=('worst16_pct','mean'),median_worst16=('worst16_pct','median'),mean_worst75=('worst_pct','mean'),median_worst75=('worst_pct','median'),max_worst75=('worst_pct','max'),new_phase_worse_cases=('worst75_minus16_pct',lambda x:int(np.count_nonzero(x>1e-10))))
    summary.to_csv(out/'SD16_Imperial27_75_vs16_Summary.csv',index=False,float_format='%.17g')
    # for each case/q the method that minimizes finite worst-phase error; paired budget competitor
    casesort=case.sort_values(['IC','q','worst_pct','method'])
    winner=casesort.loc[casesort.groupby(['IC','q']).head(1).index].copy()
    winner16=casesort.sort_values(['IC','q','worst16_pct','method']).groupby(['IC','q']).head(1)[['IC','q','method']].rename(columns={'method':'winner16'})
    winner=winner.merge(winner16,on=['IC','q'],validate='one_to_one');winner['winner_change']=winner.method!=winner.winner16
    winner.to_csv(out/'SD16_Imperial27_Finite75_Winners.csv',index=False)
    # 75-mask differences for locked cross-budget contrast (Period cubic q32 vs H1 q128)
    a=case.query('q==32 and method=="Periodic cubic"').set_index('IC');b=case.query('q==128 and method=="H1"').set_index('IC');assert len(a)==27 and len(b)==27
    contrast=pd.DataFrame({'IC':a.index,'cubic32_worst16':a.worst16_pct.values,'h1_128_worst16':b.worst16_pct.values,'cubic32_worst75':a.worst_pct.values,'h1_128_worst75':b.worst_pct.values})
    contrast['cubic_beats_h1_16']=contrast.cubic32_worst16<contrast.h1_128_worst16
    contrast['cubic_beats_h1_75']=contrast.cubic32_worst75<contrast.h1_128_worst75
    contrast.to_csv(out/'SD16_Cubic32_H1_128_75phase_Recheck.csv',index=False)
    meta={'n_sources':len(reg),'n_masks_per_q':{str(q):len(masks[q]) for q in BUDGETS},'n_scores_original_five_methods':int(len(frame[frame.method!='Nearest observed force'])),'n_scores_six_including_nearest':int(len(frame)),'archived16_max_abs_diff_W':float(olddelta.abs_diff_W.max()),'archived16_max_abs_diff_pct':float(olddelta.abs_diff_pct.max()),'n_case_budget_winner_change':int(winner.winner_change.sum()),'cubic32_H1_128_better_count_16':int(contrast.cubic_beats_h1_16.sum()),'cubic32_H1_128_better_count_75':int(contrast.cubic_beats_h1_75.sum()),'status':'post-outcome empirical extension of precisely defined finite index-phase family, no jitter/physical calibration or independent source'}
    (out/'SD16_75phase_ScienceSummary.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('SD16_EXHAUSTIVE_PASS',meta)
    print('BUDGET SUMMARY q32\n',summary.query('q==32').to_string(index=False,float_format=lambda z:f'{z:.5g}'))
    return meta
if __name__=='__main__':run()
