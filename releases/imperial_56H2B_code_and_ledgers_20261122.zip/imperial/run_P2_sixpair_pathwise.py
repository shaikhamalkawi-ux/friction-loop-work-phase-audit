#!/usr/bin/env python3
"""Six original exactly-force-matched PoliTO pairs, post-outcome pathwise work-rank audit.
Original provider raw/processed pairs are local private inputs with SHA-256 admission.
All estimator force predictions depend only on fixed sparse force samples and index,
never on either displacement representation. Not a physical uncertainty certificate.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import hashlib,itertools,json,sys
import numpy as np,pandas as pd
from scipy.io import loadmat
from scipy.interpolate import PchipInterpolator,CubicSpline
from numpy.lib.stride_tricks import sliding_window_view
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'SD10SRC/H2_SD10'))
from tdms_numeric_reader import read_tdms_numeric
N=571;BUDGETS=(16,32,64,128);METHODS=('H1','H3','Periodic linear','Periodic PCHIP','Periodic cubic');PHASES=range(16)
PAIRS=[('AF10','9900'),('AF10','997500'),('AF19','997500'),('AF10','945000'),('AF19','945000'),('AF36','480')]

def cfun(x):return .5*(np.roll(x,-1)-np.roll(x,1))
def ct_e(e):return .5*(np.roll(e,1)-np.roll(e,-1))

def sample(q,p):
 t=N*(np.arange(q)+p/16)/q
 v=np.floor(t+.5-1e-12).astype(int)%N
 assert len(np.unique(v))==q
 return np.sort(v)

def pred(method,idx,y):
 idx=np.asarray(idx,float);u=np.arange(N,dtype=float)
 if method in ['H1','H3']:
  k=1 if method=='H1' else 3
  tt=2*np.pi*idx/N;ww=2*np.pi*u/N
  design=lambda t:np.column_stack([np.ones(len(t))]+[z for j in range(1,k+1) for z in (np.sin(j*t),np.cos(j*t))])
  return design(ww)@np.linalg.lstsq(design(tt),y,rcond=None)[0]
 if method=='Periodic linear':return np.interp(u,np.r_[idx-N,idx,idx+N],np.tile(y,3))
 if method=='Periodic PCHIP':return PchipInterpolator(np.r_[idx-N,idx,idx+N],np.tile(y,3),extrapolate=False)(u)
 if method=='Periodic cubic':
  sp=CubicSpline(np.r_[idx,idx[0]+N],np.r_[y,y[0]],bc_type='periodic',extrapolate='periodic')
  return sp(((u-idx[0])%N)+idx[0])
 raise KeyError(method)

def path_summary(a,b):
 """a,b matrices (#methods,#phases) of affine signed work residuals."""
 def S(z):return np.max(np.abs(a+z*b),axis=1)
 def winner(z):return int(np.argmin(S(z)))
 lines=[]
 for method in range(len(METHODS)):
  for j in range(a.shape[1]):
   for sg in [-1,1]:lines.append((method,float(sg*a[method,j]),float(sg*b[method,j])))
 roots={0.,1.};q=len(lines)
 for ia in range(q):
  m,A,B=lines[ia]
  for ib in range(ia+1,q):
   k,C,D=lines[ib]
   if m==k:continue
   den=B-D
   if abs(den)>1e-15:
    z=(C-A)/den
    if 0<z<1:roots.add(z)
 points=sorted(roots)
 # collapse numerical duplicates near-equal to avoid degenerate segment midpoints
 unique=[points[0]]
 for x in points[1:]:
  if x-unique[-1]>2e-12:unique.append(x)
  else:unique[-1]=max(unique[-1],x)
 covered=[]
 for x,y in zip(unique[:-1],unique[1:]):
  if y-x<2e-12:continue
  w=winner((x+y)/2)
  if covered and covered[-1]['method']==METHODS[w] and abs(covered[-1]['end']-x)<1e-10:covered[-1]['end']=y
  else:covered.append({'start':x,'end':y,'method':METHODS[w]})
 w0=METHODS[winner(0)];w1=METHODS[winner(1)]
 # no ties at endpoints in admitted use; explicit margin test
 order=np.argsort(S(0));margin=float(S(0)[order[1]]-S(0)[order[0]])
 return {'winner_raw':w0,'winner_processed':w1,'endpoint_same':w0==w1,'winner_transitions':max(0,len(covered)-1),'path_constant':len(covered)==1 and w0==w1==covered[0]['method'],'intervals':covered,'start_score_gap':margin,'roots_candidate_count':len(points)-2}

reg=json.loads((R/'SD10SRC/H2_SD10/ORIGINAL_INPUT_SHA256_REGISTER.json').read_text())['input_files'];hashes={t['file']:t['sha256'] for t in reg}
rows=[];paths=[];rank_rows=[];phase_rows=[]
for cas,stage in PAIRS:
 raw=R/'paired_sources'/f'{cas}_{stage}.tdms.bin';mat=R/'paired_sources'/f'{cas}_{stage}cycle.mat.bin'
 for p in (raw,mat): assert hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name],p
 channels,_=read_tdms_numeric(raw);F=channels["/'AI'/'Friction Force'"];X=channels["/'AI'/'X*'"]*1000
 data=loadmat(mat)['hyst'];xpub,fpub=data.T;assert len(fpub)==N
 hits=np.flatnonzero(np.all(sliding_window_view(F,N)==fpub,axis=1));assert len(hits)==1
 k=int(hits[0]);xraw=X[k:k+N].copy();xraw-=np.mean(xraw)
 assert np.array_equal(F[k:k+N],fpub)
 c0=cfun(xraw);dc=cfun(xpub-xraw);w0=float(c0@fpub);dw=float(dc@fpub);w1=float(cfun(xpub)@fpub)
 assert abs(w0+dw-w1)<1e-9;assert w0!=0 and w1!=0
 for q in BUDGETS:
  a=np.zeros((len(METHODS),16));b=np.zeros_like(a);L=[];eranks=[]
  for mi,method in enumerate(METHODS):
   errs=[]
   for p in PHASES:
    obs=sample(q,p);fh=pred(method,obs,fpub[obs]);e=fh-fpub
    a[mi,p]=c0@e;b[mi,p]=dc@e;errs.append(e)
   L.append(max(float(np.linalg.norm(ct_e(e),1)) for e in errs))
  for mi,method in enumerate(METHODS):
   for phase in range(16):phase_rows.append({'case':cas,'stage':stage,'q':q,'method':method,'phase':phase,'signed_error_raw':a[mi,phase],'signed_error_slope':b[mi,phase]})
  pp=path_summary(a,b)
  S0=np.max(np.abs(a),axis=1);S1=np.max(np.abs(a+b),axis=1)
  wi=METHODS.index(pp['winner_raw']);eps=[]
  for m in range(len(METHODS)):
   if m==wi:continue
   margin=S0[m]-S0[wi]
   if margin<=0:eps.append(0.)
   elif L[wi]+L[m]>0:eps.append(float(margin/(L[wi]+L[m])))
   else:eps.append(float('inf'))
  epsrank=min(eps);actualdelta=float(np.max(np.abs(xpub-xraw)))
  rr={'case':cas,'stage':stage,'q':q,'W_raw':w0,'W_processed':w1,'abs_work_reference_change_pct':100*abs(dw)/abs(w1),'winner_raw':pp['winner_raw'],'winner_processed':pp['winner_processed'],'endpoint_same':pp['endpoint_same'],'path_winner_constant':pp['path_constant'],'path_transitions':pp['winner_transitions'],'epsilon_rank_um':epsrank,'actual_max_abs_displacement_change_um':actualdelta,'certified_winner_stability_at_observed_delta':actualdelta<epsrank,'path_candidate_roots':pp['roots_candidate_count'],'force_exact_match_count':len(hits)}
  rows.append(rr)
  for segment in pp['intervals']:paths.append({'case':cas,'stage':stage,'q':q,**segment})
  for m,method in enumerate(METHODS):
   rank_rows.append({'case':cas,'stage':stage,'q':q,'method':method,'S_raw_abs_native':float(S0[m]),'S_proc_abs_native':float(S1[m]),'L_workperturb_1':float(L[m]),'max_absolute_error_on_path':float(max(np.abs(a[m]).max(),np.abs((a+b)[m]).max()))})
 print('PAIRED_PATH_AUDIT',cas,stage,'endpoint wins',sum(x['endpoint_same'] for x in rows[-4:]),'path wins',sum(x['path_winner_constant'] for x in rows[-4:]),flush=True)
pd.DataFrame(phase_rows).to_csv(R/'results/SD16_PoliTO_SixPairs_AffinePhaseErrors.csv',index=False,float_format='%.17g')
frame=pd.DataFrame(rows);frame.to_csv(R/'results/SD16_PoliTO_SixPairs_Pathwise_WinnerAudit.csv',index=False,float_format='%.17g')
pd.DataFrame(paths).to_csv(R/'results/SD16_PoliTO_SixPairs_WinnerSegments.csv',index=False,float_format='%.17g')
pd.DataFrame(rank_rows).to_csv(R/'results/SD16_PoliTO_SixPairs_MethodMargins.csv',index=False,float_format='%.17g')
summary={'num_source_pairs':6,'num_pair_budgets':len(frame),'endpoint_same':int(frame.endpoint_same.sum()),'path_constant':int(frame.path_winner_constant.sum()),'interior_transitions_total':int(frame.path_transitions.sum()),'certified_at_actual_perturbation':int(frame.certified_winner_stability_at_observed_delta.sum()),'status':'post-outcome 6 source-pair audit; 16-phase masks and force reconstructions fixed under both displacement references; not the original 9-pair x 4-budget ledger'}
(R/'results/SD16_PoliTO_SixPairs_Pathwise_Summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PATHWISE_RESULT',summary)
print(frame[['case','stage','q','winner_raw','winner_processed','path_winner_constant','path_transitions','epsilon_rank_um','actual_max_abs_displacement_change_um']].to_string(index=False,float_format=lambda x:f'{x:.5g}'))
