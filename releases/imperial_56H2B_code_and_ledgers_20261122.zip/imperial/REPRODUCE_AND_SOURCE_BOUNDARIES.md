# E10 / SD16 — Executable evidence and source boundaries

The package is an **analysis release candidate** for two retrospective studies. No new experiment, physically calibrated work benchmark, new general mathematical theorem, independently blinded test set or journal approval is claimed.

## Scientific separation

- **Machines E10:** withholds both position and force in indexed loops. Primary endpoint is paired displacement--force joint NRMSE for scattered or contiguous missingness. Core source programme is the Fantetti round robin, including both PoliTO and Imperial rigs, and an independent ARTS damper source programme for stress testing.
- **Numerical Work SD16:** always provides the full stored displacement and withholds force observations at budget and phase masks. Target is a **declared signed closed-polygon numerical integral**, with retrospective relative or absolute differences. No measured calibrated dissipation.

## Reproduce from derived results only

From the extracted root with Python >=3.10 and NumPy/Pandas/SciPy installed:

```bash
python verify_E10_SD16_derived.py
```

This audits the 75-mask family, rows, original 8640-score parity, comparator sets, P1 SVD/CV summaries, and source-pair pathwise totals. It does **not** read original physical records or independently re-fit stored experiments.

## Reproduce from original source (provided separately by the original data creators)

1. Obtain the original Fantetti et al. dataset, Mendeley Data version 1: https://doi.org/10.17632/gy587m7gx7.1.
2. For the 27 Imperial processed source cases, place each selected `hyst` MAT file under `private_inputs/IC{IC}_cycle{cycle_id}.mat` (the source manifest is `EVID/docs/LOCKED_27_SOURCE_SHA256.csv`). The `sha256` and `size` fields are enforced before scoring.
3. For the six paired PoliTO raw-source files and processed MAT files, use the fixed paths `paired_sources/AF10_9900.tdms.bin` / `paired_sources/AF10_9900cycle.mat.bin`, etc. The exact 12 SHA-256 values are recorded in `SD10SRC/H2_SD10/ORIGINAL_INPUT_SHA256_REGISTER.json`. The included minimal reader is `SD10SRC/H2_SD10/tdms_numeric_reader.py`.
4. From the extracted root, install dependencies and run:

```bash
python run_P2_exhaustive_75.py
python run_P1_diagnostic.py
python run_P1_original_index_cv.py
python run_P2_sixpair_pathwise.py
python verify_E10_SD16_derived.py
```

Replays write `results/*.csv` and `results/*.json`. `run_P2_exhaustive_75.py` asserts case-by-case numeric parity with the previous 8640 phase-16 scores. As in the analysis itself, the improvement of new source-index CV is **not assumed**.

## Scope and trust boundaries

- 27 conditions are measured trajectories from one two-rig round robin, not 27 independent labs. Multiple phase masks and dependent cycles are not independent physical units.
- The finite 75-mask result is exact **within the stated nearest-index phase family**; it says nothing universal about asynchronous instrumentation or all sampling schedules.
- The new pathwise test is 6 paired records x 4 budgets, not the earlier locked 9-pair endpoint comparison. It fixes sparse-force observation sets and dense reconstructions when changing displacement; recomputing a displacement-driven sampling design would invalidate that bound.
- `epsilon_rank` is a **sufficient** conservative bound only. Failure of the guarantee does not demonstrate a winner reversal.
- Provider-processed `hyst` source identity and numerical agreement do not establish an authoritative historical MATLAB source script or calibration validity.
- Numerical error distributions, root results, and selected reviewer-driven additions are retrospective/post-outcome. They cannot be treated as preregistration or blind external validation.
- Code/data licensing and public DOI are NOT asserted. Original provider MAT/TDMS are not redistributed.

## Editable paper sources

The two separate Overleaf source ZIPs contain main/supplement TEX files, MDPI class assets (where applicable), and all cited image assets. Unzip each into a separate LaTeX project and compile `main.tex` or `supplement.tex` individually. Do not upload the shared scientific ZIP to Overleaf as the manuscript source.
