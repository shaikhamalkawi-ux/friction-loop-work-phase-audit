import sys,struct,pathlib,numpy as np
from scipy.io import loadmat

def read_tdms_numeric(p):
 b=pathlib.Path(p).read_bytes();pos=0;channels={};props_by_path={}
 def u32(k):return struct.unpack_from('<I',b,k)[0]
 def u64(k):return struct.unpack_from('<Q',b,k)[0]
 def parse_prop(k,typ):
  if typ==0x20:
   z=u32(k);return b[k+4:k+4+z].decode('utf-8','replace'),k+4+z
  if typ==0x44:
   return (u64(k),u64(k+8)),k+16
  dt=np.dtype({1:'i1',2:'<i2',3:'<i4',4:'<i8',5:'u1',6:'<u2',7:'<u4',8:'<u8',9:'<f4',10:'<f8',0x21:'?'}.get(typ, '<u8'))
  return np.frombuffer(b,dtype=dt,count=1,offset=k)[0].item(),k+dt.itemsize
 while pos<len(b):
  sig,toc,version,nextoff,raw_off=struct.unpack_from('<4sIIQQ',b,pos)
  assert sig==b'TDSm' and version==4713
  assert toc&0x04
  k=pos+28;n=u32(k);k+=4;raws=[]
  for j in range(n):
   z=u32(k);k+=4;name=b[k:k+z].decode();k+=z
   idxlen=u32(k);k+=4;ri=None
   if idxlen not in (0,0xffffffff):
    assert idxlen==20
    dtyp,dim,num=struct.unpack_from('<IIQ',b,k);k+=idxlen-4
    ri=(dtyp,num)
   nprops=u32(k);k+=4;pr={}
   for npp in range(nprops):
    z=u32(k);k+=4;pn=b[k:k+z].decode();k+=z;typ=u32(k);k+=4;val,k=parse_prop(k,typ);pr[pn]=val
   props_by_path.setdefault(name,{}).update(pr)
   if ri is not None:raws.append((name,*ri))
  assert k==pos+28+raw_off
  k=pos+28+raw_off
  for name,typ,num in raws:
   fmt={9:'<f4',10:'<f8',3:'<i4',7:'<u4'}[typ]
   vals=np.frombuffer(b,dtype=fmt,count=num,offset=k).copy();k+=vals.nbytes
   channels[name]=np.concatenate([channels[name],vals]) if name in channels else vals
  assert k==pos+28+nextoff
  pos=pos+28+nextoff
 return channels,props_by_path

if __name__=='__main__':
 raw='/mnt/data/AF10_10mm2_1mum_175Hz_86N_997500.tdms.bin';mat='/mnt/data/997500cycle.mat.bin'
 chans,props=read_tdms_numeric(raw)
 print('channels',[(k, v.shape,float(np.nanmin(v)),float(np.nanmax(v))) for k,v in chans.items()])
 F=chans["/'AI'/'Friction Force'"]
 X=chans["/'AI'/'X*'"]*1000.
 cyc=chans["/'AI'/'CurrentCycle'"]
 ym=loadmat(mat)['hyst']; xpub,fpub=ym.T
 from numpy.lib.stride_tricks import sliding_window_view
 idx=np.flatnonzero(np.all(sliding_window_view(F,len(fpub))==fpub,axis=1));print('matches',idx)
 if len(idx):
  z=X[idx[0]:idx[0]+len(xpub)]
  print('Xraw range',z.min(),z.max(),'Xpub range',xpub.min(),xpub.max())
  print('raw global mean',X.mean(),'Xraw segment mean',z.mean(),'Xpub mean',xpub.mean())
  print('raw-centered vs pub x max',np.max(np.abs((z-z.mean())-xpub)), 'rms',np.mean(((z-z.mean())-xpub)**2)**.5)
  print('raw-to-pub linear slope/intercept',np.polyfit(z,xpub,1))
  print('samples first 5 raw',z[:5], 'pub',xpub[:5],'diff',xpub[:5]-z[:5])
  def work(x,F):return 0.5*np.sum((F+np.roll(F,-1))*(np.roll(x,-1)-x))
  print('work raw',work(z,fpub),'processed',work(xpub,fpub),'pct',100*(work(xpub,fpub)-work(z,fpub))/work(xpub,fpub))
  print('range stage',cyc[idx[0]],cyc[idx[0]+len(xpub)-1])
