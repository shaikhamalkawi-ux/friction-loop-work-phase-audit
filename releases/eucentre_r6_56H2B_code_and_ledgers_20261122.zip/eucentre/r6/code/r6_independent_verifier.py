#!/usr/bin/env python3
"""Independent R6 derived-output checks and alternate polygon-work spot path.

No raw redistribution. Inputs include BED original for spot checks only. Verifies
four-arm scores against a second polygon quadrature formulation, source-gated.
"""
import csv, json, zipfile,io,hashlib,sys,argparse
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
from scipy.interpolate import CubicSpline,PchipInterpolator

pa=argparse.ArgumentParser()
pa.add_argument('--source',required=True)
pa.add_argument('--inputs',required=True)
pa.add_argument('--results',default=None)
pa.add_argument('--report-dir',default=None)
args=pa.parse_args()
root=Path(__file__).resolve().parents[1]
src=Path(args.source)
inputs=Path(args.inputs)
results_dir=Path(args.results) if args.results else root/'results'
report_dir=Path(args.report_dir) if args.report_dir else root/'qa'
report_dir.mkdir(parents=True,exist_ok=True)
assert hashlib.sha256(src.read_bytes()).hexdigest()=='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c'

def table(name):
 with (results_dir/name).open(newline='',encoding='utf8') as f:return list(csv.DictReader(f))
A=table('R6_FACT_48K_ERRORS.csv');B=table('R6_FACT_PHASE_CHOICES.csv');C=table('R6_FACT_METHOD_WORST.csv');D=table('R6_FACT_WORST_WINNERS.csv')
assert len(A)==48600 and len(B)==2025 and len(C)==648 and len(D)==108
idx={(int(r['test_id']),int(r['phase_id']),r['method'],r['arm']):r for r in A};assert len(idx)==len(A)
phase={(int(r['test_id']),int(r['phase_id'])):r for r in B};assert len(phase)==2025
r5=table('R6_FACT_NINE_FELT_GROUPS.csv');assert len(r5)==9 and sum(int(r['both_changes']) for r in r5)==143
counts={k:sum(int(r[k]) for r in B) for k in ['force_only_changed','displacement_only_changed','both_changed','rank_change_force_only','rank_change_x_only','rank_change_both']}
assert counts=={'force_only_changed':144,'displacement_only_changed':17,'both_changed':143,'rank_change_force_only':272,'rank_change_x_only':82,'rank_change_both':300}
# Reproduce every phase method ranking using stored row errors, no dependence on original run's in-memory winners.
for (tid,pid),pr in phase.items():
 ranks={}
 for arm in ['RR','RP','PR','PP']:
  scored=sorted((float(idx[tid,pid,m,arm]['relative_error_pct']),m) for m in ('H1','H3','linear','pchip','cubic','nearest'))
  ranks[arm]=scored[0][1]
  assert ranks[arm]==pr['winner_'+arm]
 assert int(pr['force_only_changed'])==int(ranks['RR']!=ranks['RP'])
 assert int(pr['displacement_only_changed'])==int(ranks['RR']!=ranks['PR'])
 assert int(pr['both_changed'])==int(ranks['RR']!=ranks['PP'])
# Recompute worst-of-phase by independent grouping of the saved scores.
by=defaultdict(list)
for r in A:by[int(r['test_id']),r['arm'],r['method']].append(float(r['relative_error_pct']))
for r in C:
 t,a,m=int(r['test_id']),r['arm'],r['method'];assert len(by[t,a,m])==75
 assert abs(max(by[t,a,m])-float(r['worst_phase_error_pct']))<1e-10
for r in D:
 t,a=int(r['test_id']),r['arm']; order=sorted((max(by[t,a,m]),m) for m in ('H1','H3','linear','pchip','cubic','nearest'))
 assert r['winner']==order[0][1]=='cubic' and r['runner_up']==order[1][1]=='pchip'
 assert abs(float(r['margin_pp'])-float(order[1][0]-order[0][0]))<1e-10
# A second direct polygon quadrature path for fixed 9 files and 3 phase masks,
# H1/H3/linear/PCHIP/cubic/nearest. Source ZIP check was already source-gated.
Z=zipfile.ZipFile(src);assert Z.testzip() is None
P={int(r['test_id']):r for r in csv.DictReader(open(inputs/'R5_ORIGINAL_CYCLE_PROVENANCE.csv',newline=''))}
methods=['H1','H3','linear','pchip','cubic','nearest']
max_e=0.0;n=0
for tid in [14,15,16,20,24,27,31,36,40]:
 p=P[tid]['pressure'];st=int(P[tid]['frozen_cycle_start_index_zero_based'])
 r=np.loadtxt(io.BytesIO(Z.read(f'Cyclic/Raw/test{tid}_{p}_raw.txt')))[st:st+2400]
 q=np.loadtxt(io.BytesIO(Z.read(f'Cyclic/Processed/test{tid}_{p}_processed.txt')))[st:st+2400]
 X={'R':r[:,0],'P':q[:,0]};F={'R':r[:,1],'P':q[:,1]};t=np.arange(2400)
 phase_groups={}
 for pid in [0,37,74]:
  for arm in ['RR','RP','PR','PP']:
   k=(tid,pid,'H1',arm);masksha=idx[k]['mask_sha256'];phase_groups.setdefault(pid,masksha)
  # Reconstruct the frozen rounded uniform mask from R6 mask-hash membership.
  from fractions import Fraction
  borders=sorted({Fraction((2*j+1)*32,2*2400)%1 for j in range(2400)})
  alpha=float(((borders[pid]+(borders[pid+1] if pid+1<len(borders) else borders[0]+1))/2)%1)
  oi=np.sort((np.floor(2400*(np.arange(32)+alpha)/32+0.5).astype(int)%2400))
  assert hashlib.sha256(np.asarray(oi,dtype='<i4').tobytes()).hexdigest()==masksha
  ext=np.r_[oi[-1]-2400,oi,oi[0]+2400]
  for ff in ['R','P']:
   vals=F[ff][oi]; reps={}
   for kh in [1,3]:
    basis=np.column_stack([np.ones(2400)]+[v for kk in range(1,kh+1) for v in (np.sin(2*np.pi*kk*t/2400),np.cos(2*np.pi*kk*t/2400))]);reps['H'+str(kh)]=basis@np.linalg.pinv(basis[oi])@vals
   reps['linear']=np.interp(t,ext,np.r_[vals[-1],vals,vals[0]])
   reps['pchip']=PchipInterpolator(np.r_[oi-2400,oi,oi+2400],np.tile(vals,3),extrapolate=False)(t)
   tc=np.where(t<oi[0],t+2400,t)
   reps['cubic']=CubicSpline(np.r_[oi,oi[0]+2400],np.r_[vals,vals[0]],bc_type='periodic',extrapolate='periodic')(tc)
   ix=np.searchsorted(oi,t,'left'); right=oi[ix%len(oi)]; left=oi[(ix-1)%len(oi)]
   dleft=(t-left)%2400;dright=(right-t)%2400
   pick=np.where((dleft<dright)|((dleft==dright)&(left<=right)),(ix-1)%len(oi),ix%len(oi))
   reps['nearest']=vals[pick]
   for xx in ['R','P']:
    arm=xx+ff;x=X[xx];y=F[ff]
    wref=np.trapezoid(np.r_[y,y[0]],np.r_[x,x[0]])
    for m in methods:
     ph=reps[m]; w_est=np.trapezoid(np.r_[ph,ph[0]],np.r_[x,x[0]])
     measured=float(idx[tid,pid,m,arm]['signed_estimator_error_kNmm'])
     err=float(w_est-wref)
     max_e=max(max_e,abs(measured-err));n+=1
     assert abs(measured-err)<1e-8, (tid,pid,arm,m,err,measured)
report={'source_sha_pass':True,'row_count':len(A),'phase_arm_count':4*len(B),'unique_masks':len(B),'method_case_rows':len(C),'worst_of_phase_rows':len(D),'all_phase_winners_recomputed':True,'all_case_worst_winners_recomputed':True,'nine_felt_sets':9,'counts':counts,'independent_alternate_closed_polygon_spot_checks':n,'max_spot_error_kNmm':max_e,'result':'PASS','scope':'numerical only; no calibration or independent laboratory experiments'}
(report_dir/'R6_INDEPENDENT_VERIFIER.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
