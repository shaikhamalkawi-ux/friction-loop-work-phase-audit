#!/usr/bin/env python3
"""R6: source-gated 2x2 channel-processing factorial, numerical-only.

Creates counterfactual crossed (x_raw, F_proc) and (x_proc, F_raw) arrays;
these are NOT laboratory observation streams. The reference is the dense
closed polygon computed within each crossed representation. Source SHA gate
and exact R5 RR / PP score parity required. Unmodified SD21 six methods.
"""
from __future__ import annotations
import argparse,csv,hashlib,io,json,math,sys,zipfile
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np

N=2400
SOURCE_SHA='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c'
METHODS=('H1','H3','linear','pchip','cubic','nearest')
ARMS=('RR','RP','PR','PP') # x first, F second

def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for ch in iter(lambda:f.read(8*1024*1024),b''):h.update(ch)
 return h.hexdigest()

def read_csv(p):
 with open(p,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def write_csv(p,rows):
 if not rows:raise ValueError(p)
 with open(p,'w',encoding='utf-8',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()));writer.writeheader();writer.writerows(rows)

def calc_quantiles(xs):
 a=np.array(list(xs),dtype=float)
 return {'n':len(a),'min':float(np.min(a)),'mean':float(np.mean(a)),'median':float(np.median(a)),'max':float(np.max(a))}

def load_frozen_solver(path):
 sys.path.insert(0,str(path))
 import retained_sd21_eucentre as solver
 assert tuple(solver.METHODS)==METHODS
 return solver

def main():
 pa=argparse.ArgumentParser()
 pa.add_argument('--source',required=True);pa.add_argument('--r5-dir',required=True);pa.add_argument('--r5-code-dir',required=True);pa.add_argument('--out',required=True)
 args=pa.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 assert digest(args.source)==SOURCE_SHA,'Raw source hash mismatch'
 r5dir=Path(args.r5_dir);frozen=load_frozen_solver(Path(args.r5_code_dir))
 z=zipfile.ZipFile(args.source);assert z.testzip() is None
 provenance={int(row['test_id']):row for row in read_csv(Path(args.r5_code_dir)/'R5_ORIGINAL_CYCLE_PROVENANCE.csv')}
 retained={(int(r['test_id']),int(r['phase_id']),r['method']):r for r in read_csv(r5dir/'R5_PAIRED_Q32_ALL_SCORES.csv')}
 assert len(provenance)==27 and len(retained)==27*75*6
 masks=frozen.phase_masks(N,32);assert len(masks)==75
 t=np.arange(N,dtype=float);theta=2*np.pi*t/N
 basis=np.column_stack([np.ones(N)]+[vector for k in range(1,4) for vector in (np.sin(k*theta),np.cos(k*theta))])
 rows=[];winners=[];method_case=[];arm_ref=[];max_parity=0.0;max_work_func=0.0
 for tid in range(14,41):
  pr=provenance[tid];p=pr['pressure'];group=int(pr['felt_set']);start=int(pr['frozen_cycle_start_index_zero_based'])
  xr=np.loadtxt(io.BytesIO(z.read(f'Cyclic/Raw/test{tid}_{p}_raw.txt')))[start:start+N]
  xp=np.loadtxt(io.BytesIO(z.read(f'Cyclic/Processed/test{tid}_{p}_processed.txt')))[start:start+N]
  assert xr.shape==xp.shape==(N,2) and np.isfinite(xr).all() and np.isfinite(xp).all()
  x={'R':xr[:,0], 'P':xp[:,0]};F={'R':xr[:,1],'P':xp[:,1]}
  c={k:frozen.work_coeff(xx) for k,xx in x.items()}
  ref={a:float(c[a[0]]@F[a[1]]) for a in ARMS}
  for a in ARMS:
   polygon=frozen.polygon(x[a[0]],F[a[1]])
   max_work_func=max(max_work_func,abs(ref[a]-polygon))
  assert math.isclose(ref['RR'],float(pr['raw_cycle_work_kNmm']),rel_tol=1e-13,abs_tol=2e-10)
  assert math.isclose(ref['PP'],float(pr['processed_cycle_work_kNmm']),rel_tol=1e-13,abs_tol=2e-10)
  for a in ARMS:
   arm_ref.append({'test_id':tid,'felt_set':group,'pressure':p,'arm':a,'work_kNmm':ref[a]})
  for pid,(alpha,idx) in enumerate(masks):
   hashmask=hashlib.sha256(np.asarray(idx,dtype='<i4').tobytes()).hexdigest()
   pred={key:dict(frozen.sparse_force_solvers(idx,F[key][idx],N,basis)) for key in ['R','P']}
   assert all(set(pred[key])==set(METHODS) for key in ['R','P'])
   errors={a:{} for a in ARMS};signed={a:{} for a in ARMS}
   for method in METHODS:
    old=retained[(tid,pid,method)]
    assert old['mask_sha256']==hashmask and int(old['felt_set'])==group
    for a in ARMS:
     err=float(c[a[0]]@(pred[a[1]][method]-F[a[1]]))
     signed[a][method]=err
     percent=100*abs(err)/abs(ref[a]);errors[a][method]=percent
     if a in ('RR','PP'):
      delta=abs(percent-float(old['raw_relative_error_pct'] if a=='RR' else old['processed_relative_error_pct']))
      max_parity=max(max_parity,delta)
      assert delta<2e-9, f'R5 parity mismatch {tid},{pid},{method},{a},{delta}'
     rows.append({'test_id':tid,'felt_set':group,'pressure':p,'phase_id':pid,'mask_sha256':hashmask,'method':method,'arm':a,
       'numerical_dense_work_kNmm':ref[a],'signed_estimator_error_kNmm':err,'relative_error_pct':percent})
   for a in ARMS:
    ranked=sorted(METHODS,key=lambda m:(errors[a][m],METHODS.index(m)))
    winners.append({'test_id':tid,'felt_set':group,'pressure':p,'phase_id':pid,'arm':a,'winner':ranked[0],
      'second':ranked[1],'margin_pp':errors[a][ranked[1]]-errors[a][ranked[0]],'complete_order':';'.join(ranked)})
  print('test',tid,'passed',flush=True)
 assert len(rows)==4*27*75*6 and len(winners)==4*27*75
 assert max_parity<2e-9 and max_work_func<1e-9
 win_lookup={(r['test_id'],r['phase_id'],r['arm']):r for r in winners}
 pairs=[]
 for tid in range(14,41):
  for pid in range(75):
   a={arm:win_lookup[tid,pid,arm] for arm in ARMS}
   pairs.append({'test_id':tid,'felt_set':int(a['RR']['felt_set']),'pressure':a['RR']['pressure'],'phase_id':pid,
    'winner_RR':a['RR']['winner'],'winner_RP':a['RP']['winner'],'winner_PR':a['PR']['winner'],'winner_PP':a['PP']['winner'],
    'force_only_changed':int(a['RR']['winner']!=a['RP']['winner']),
    'displacement_only_changed':int(a['RR']['winner']!=a['PR']['winner']),
    'both_changed':int(a['RR']['winner']!=a['PP']['winner']),
    'processing_force_after_x_changed':int(a['PR']['winner']!=a['PP']['winner']),
    'processing_x_after_force_changed':int(a['RP']['winner']!=a['PP']['winner']),
    'rank_change_force_only':int(a['RR']['complete_order']!=a['RP']['complete_order']),
    'rank_change_x_only':int(a['RR']['complete_order']!=a['PR']['complete_order']),
    'rank_change_both':int(a['RR']['complete_order']!=a['PP']['complete_order']),
    'raw_margin_pp':float(a['RR']['margin_pp']),'processed_margin_pp':float(a['PP']['margin_pp'])})
 assert sum(r['both_changed'] for r in pairs)==143
 assert sum(r['rank_change_both'] for r in pairs)==300
 # Worst-of-phase selection is determined anew for each crossed arm.
 for tid in range(14,41):
  for arm in ARMS:
   arr=[]
   for method in METHODS:
    sub=[r['relative_error_pct'] for r in rows if r['test_id']==tid and r['arm']==arm and r['method']==method]
    assert len(sub)==75
    arr.append({'test_id':tid,'felt_set':int(provenance[tid]['felt_set']),'pressure':provenance[tid]['pressure'],
      'arm':arm,'method':method,'worst_phase_error_pct':max(sub),'median_phase_error_pct':float(np.median(sub))})
   method_case.extend(arr)
 worst=[]
 for tid in range(14,41):
  for arm in ARMS:
   part=sorted((r for r in method_case if r['test_id']==tid and r['arm']==arm),key=lambda r:(r['worst_phase_error_pct'],METHODS.index(r['method'])))
   worst.append({'test_id':tid,'felt_set':int(provenance[tid]['felt_set']),'pressure':provenance[tid]['pressure'],'arm':arm,
    'winner':part[0]['method'],'runner_up':part[1]['method'],'margin_pp':part[1]['worst_phase_error_pct']-part[0]['worst_phase_error_pct']})
 # Multiple independent grouping views to avoid treating every mask as experimental replication.
 group=[]
 for g in range(1,10):
  p=[r for r in pairs if r['felt_set']==g]
  assert len(p)==3*75
  group.append({'felt_set':g,'n_tests':3,'n_masks':len(p),'force_only_changes':sum(r['force_only_changed'] for r in p),
  'displacement_only_changes':sum(r['displacement_only_changed'] for r in p),
  'both_changes':sum(r['both_changed'] for r in p),'force_only_rate':np.mean([r['force_only_changed'] for r in p]),
  'displacement_only_rate':np.mean([r['displacement_only_changed'] for r in p]),
  'both_rate':np.mean([r['both_changed'] for r in p])})
 summary={
 'scope':'RETROSPECTIVE CROSSED-CHANNEL NUMERICAL COUNTERFACTUAL; NOT A PHYSICAL PROCESSING EXPERIMENT',
 'source_sha256':SOURCE_SHA,'original_method_protocol':'unaltered six SD21 force-only estimator definitions',
 'n_felt_sets':9,'n_tests':27,'q':32,'masks_per_test':75,'n_scenario_masks':2025,'n_estimator_arm_rows':len(rows),
 'R5_RR_PP_exact_parity_max_error_pp':max_parity,'polygon_dot_identity_max_kNmm':max_work_func,
 'phase_winner_switches':{k:sum(r[k] for r in pairs) for k in ['force_only_changed','displacement_only_changed','both_changed','processing_force_after_x_changed','processing_x_after_force_changed']},
 'full_order_switches':{k:sum(r[k] for r in pairs) for k in ['rank_change_force_only','rank_change_x_only','rank_change_both']},
 'worst_phase_winners':{arm:dict(Counter(r['winner'] for r in worst if r['arm']==arm)) for arm in ARMS},
 'minimum_worst_phase_winner_margin_pp':{arm:min(r['margin_pp'] for r in worst if r['arm']==arm) for arm in ARMS},
 'group_range_both_rate':[float(min(r['both_rate'] for r in group)),float(max(r['both_rate'] for r in group))],
 'processed_signals_not_equivalent_to_independent_raw_sensors':True,
 'not_an_estimate_of_calibrated_physical_interface_dissipation':True,
 'joint_factor_responses_not_additive_for_argmin_winners':True,
 }
 for name,data in [('R6_FACT_48K_ERRORS.csv',rows),('R6_FACT_PHASE_CHOICES.csv',pairs),('R6_FACT_METHOD_WORST.csv',method_case),('R6_FACT_WORST_WINNERS.csv',worst),('R6_FACT_NINE_FELT_GROUPS.csv',group),('R6_FACT_ARM_WORK_REFERENCES.csv',arm_ref)]:write_csv(out/name,data)
 (out/'R6_FACT_SUMMARY.json').write_text(json.dumps(summary,indent=2,default=lambda o:float(o) if isinstance(o,np.floating) else int(o) if isinstance(o,np.integer) else str(o))+'\n',encoding='utf8')
 print(json.dumps(summary,indent=2,default=lambda o:float(o) if isinstance(o,np.floating) else int(o) if isinstance(o,np.integer) else str(o)),flush=True)

if __name__=='__main__':main()
