from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text())
checked=0
for row in manifest['files']:
 p=root/row['path'];assert p.is_file(),f'FILE MISSING {p}'
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 assert digest==row['sha256'],f'HASH MISMATCH {row["path"]}'
 assert p.stat().st_size==row['bytes'],f'SIZE MISMATCH {row["path"]}'
 checked+=1
print('PASS',checked,'manifest files')
