# H2 SD21 R6 — crossed-channel numerical processing control

**Scope:** source-identity-gated retrospective numerical analysis on BED EUCENTRE dataset 34. The four arms RR, RP, PR, PP describe crossed pairings of archived numerical columns. RP and PR are mathematical counterfactuals **not laboratory measurements**. Source calibration and channel timing remain unknown. The source itself is **not distributed** here.

## Input requirements

- Original BED/EUCENTRE `Felt_TestData.zip`, separately acquired from https://experiments.builtenvdata.eu/datasets/34/ and matching SHA-256:
  `060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c`
- The bundled `inputs/R5_ORIGINAL_CYCLE_PROVENANCE.csv` and `inputs/R5_PAIRED_Q32_ALL_SCORES.csv` (previously fixed R5 ledgers).
- The bundled `inputs/retained_sd21_eucentre.py` (previously fixed six-estimator implementation).
- Python 3.11+; tested with Python 3.13, numpy 2.3.5, scipy 1.17.0.

## Clean execution from any directory

From the extracted archive root, install requirements, then run:

```bash
python -m pip install -r requirements.txt
python code/r6_cross_channel_processing.py \
  --source /path/to/Felt_TestData.zip \
  --r5-dir inputs \
  --r5-code-dir inputs \
  --out replay
python code/r6_independent_verifier.py \
  --source /path/to/Felt_TestData.zip \
  --inputs inputs \
  --results replay \
  --report-dir replay_qa
```

Run `python code/verify_manifest.py` from the extracted root to verify immutable expected results and code hashes. To compare output files bytewise, run `sha256sum` on `replay/R6_FACT_*.csv` and compare with `MANIFEST_SHA256.json` `results/` rows. Output order and decimal text are deterministic in the tested environment; bytewise parity on arbitrary scientific stacks is not guaranteed.

## Experimental boundary

Exactly 27 source tests from nine reused felt sets in one apparatus, one q=32 sparse-force budget, 75 distinct index-phase masks per test, six fixed methods and four diagnostic channel pairings. The 48,600 factor rows and 2,025 mask groups are **dependent numerical calculations**, not 48,600 independent tests or new specimens. The archived Processed series derives from a dense Raw record; 32 Processed samples are **not** equivalent to 32 independent Raw sensor readings. No published metrological uncertainty, calibrated interfacial dissipation, or cross-laboratory transfer is claimed.
