#!/usr/bin/env python3
"""Source-locked EUCENTRE external-programme numerical H2 transfer.

Requires original BED EUCENTRE #34 ZIP; does not distribute original recordings.
Protocol: FROZEN_EUCENTRE_EXTERNAL_PROTOCOL_v1.md (SHA  befb618...).
This code is an executable implementation; no hidden-force model fitting or tuning.
"""
import argparse,csv,hashlib,io,json,math,re,zipfile,sys, time
from collections import Counter,defaultdict
from fractions import Fraction
from pathlib import Path
import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import median_filter
from scipy.interpolate import PchipInterpolator, CubicSpline

N=2400
BUDGETS=(16,32,64,128)
METHODS=('H1','H3','linear','pchip','cubic','nearest')
M1=('linear','pchip','natural_cubic')
SOURCE_DIGEST='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c'
EXTREMA_HEIGHT=28.5
EXTREMA_PROM=25.0

def checksum(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def ascsv(path, rows, fieldnames=None):
 path.parent.mkdir(parents=True,exist_ok=True)
 rows=list(rows)
 if not rows: raise ValueError('No rows for '+str(path))
 with path.open('w',encoding='utf8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fieldnames or list(rows[0])); w.writeheader();w.writerows(rows)

def polygon(x,force):
 return float(np.sum((force+np.roll(force,-1))*(np.roll(x,-1)-x)*0.5))

def work_coeff(x):
 return (np.roll(x,-1)-np.roll(x,1))/2.

def load_cycle(archive,path):
 raw=np.loadtxt(io.BytesIO(archive.read(path)),dtype=np.float64)
 if raw.ndim!=2 or raw.shape[1]!=2 or not np.isfinite(raw).all():raise ValueError(f'Bad paired source {path}')
 x=raw[:,0]; force=raw[:,1]; nf=len(x)
 sm=median_filter(x,size=31,mode='nearest')
 p,_=find_peaks(sm,height=EXTREMA_HEIGHT,prominence=EXTREMA_PROM,distance=nf//6)
 n,_=find_peaks(-sm,height=EXTREMA_HEIGHT,prominence=EXTREMA_PROM,distance=nf//6)
 allpeaks=sorted([(int(z),'+' ) for z in p]+[(int(z),'-') for z in n])
 if len(p)!=2 or len(n)!=2 or len(allpeaks)!=4:raise ValueError(f'Four-extrema guard {path} {allpeaks}')
 if not all(allpeaks[i][1]!=allpeaks[i+1][1] for i in range(3)):raise ValueError(f'Alternating extrema guard {path}')
 if abs(allpeaks[2][0]-allpeaks[0][0]-N)>3:raise ValueError(f'Extrema periodicity guard {path}')
 start=allpeaks[0][0]
 if start+N>=nf:raise ValueError(f'Insufficient suffix {path}')
 if abs(x[start+N]-x[start])>0.5:raise ValueError(f'Closure x guard {path}: {x[start+N]-x[start]}')
 xs=x[start:start+N].copy(); fs=force[start:start+N].copy()
 rx=float(np.ptp(xs)); rf=float(np.ptp(fs)); work=polygon(xs,fs)
 if not np.isfinite(work) or abs(work)<1e-8 or rx<55 or rf<0.01:raise ValueError(f'Degenerate case {path}')
 return xs,fs, dict(n_original=nf,first_peak_index=start,all_four_peak_indices=';'.join(str(p[0]) for p in allpeaks),first_peak_sign=allpeaks[0][1],next_same_sign_peak_sep=allpeaks[2][0]-start,closure_displacement_gap_mm=float(x[start+N]-x[start]),x_range_mm=rx,force_range_kN=rf,signed_work_kNmm=work,raw_file_sha256=hashlib.sha256(archive.read(path)).hexdigest())

def phase_masks(n,q):
 # All transitions for the nearest half-down q-of-n rounded-uniform family.
 borders=sorted(set(Fraction((2*j+1)*q,2*n)%1 for j in range(n)))
 if len(borders) != n//math.gcd(n,q):raise AssertionError(f'Transition count {n,q,len(borders)}')
 out=[]
 for i,left in enumerate(borders):
  right=borders[i+1] if i<len(borders)-1 else borders[0]+1
  alpha=float((left+right)/2 % 1)
  indexes=np.floor(n*(np.arange(q,dtype=np.float64)+alpha)/q+0.5).astype(int)%n
  indexes=np.sort(indexes)
  if len(np.unique(indexes))!=q:raise AssertionError('duplicate observed index')
  out.append((alpha,indexes))
 if len({tuple(s.tolist()) for _,s in out})!=len(out):raise AssertionError(f'duplicate phase mask at q={q}')
 # Every one of original 16 evenly spaced phase shifts must fall in admitted exhaustive set.
 known={tuple(s.tolist()) for _,s in out}
 for k in range(16):
  cand=tuple(np.sort((np.floor(n*(np.arange(q,dtype=float)+k/16)/q+0.5-1e-11).astype(int)%n)).tolist())
  if cand not in known:raise AssertionError(f'16 phase not subset {q,k}')
 return out

def interpolate_channel(obs,y,eval_grid,method):
 if method=='linear':return np.interp(eval_grid,obs,y)
 if method=='pchip':return PchipInterpolator(obs,y,extrapolate=True)(eval_grid)
 if method=='natural_cubic':return CubicSpline(obs,y,bc_type='natural',extrapolate=True)(eval_grid)
 raise ValueError(method)

def sparse_force_solvers(indices,sampled_force,n,full_design):
 idx=indices; y=sampled_force; t=np.arange(n,dtype=float)
 # same basis and observed force for H1, H3; sample-index period n.
 for kk,method in [(1,'H1'),(3,'H3')]:
  B=full_design[:,:1+2*kk]
  beta=np.linalg.lstsq(B[idx],y,rcond=None)[0]
  yield method,B@beta
 # closed period extensions for the circular non-parametric interpolants
 ext_idx=np.r_[idx[-1]-n,idx,idx[0]+n]
 ext_val=np.r_[y[-1],y,y[0]]
 yield 'linear', np.interp(t,ext_idx,ext_val)
 ext_idx3=np.r_[idx-n,idx,idx+n]
 ext_val3=np.tile(y,3)
 yield 'pchip',PchipInterpolator(ext_idx3,ext_val3,extrapolate=False)(t)
 # Cubic spline uses a periodic joint at first selected source index.
 idx_c=np.r_[idx,idx[0]+n]
 val_c=np.r_[y,y[0]]
 tc=np.where(t < idx[0],t+n,t)
 yield 'cubic',CubicSpline(idx_c,val_c,bc_type='periodic',extrapolate='periodic')(tc)
 # circular nearest, tie: lower numeric source index
 insertion=np.searchsorted(idx,t,'left');right=idx[insertion%len(idx)];left=idx[(insertion-1)%len(idx)]
 dr=(right-t)%n;dl=(t-left)%n
 take_left=(dl<dr)|((dl==dr)&(left<=right))
 positions=np.where(take_left,(insertion-1)%len(idx),insertion%len(idx))
 yield 'nearest', y[positions]

def main(zip_path,out):
 t0=time.monotonic();out.mkdir(exist_ok=True,parents=True)
 assert checksum(zip_path)==SOURCE_DIGEST,'Original ZIP SHA-256 mismatch'
 zipf=zipfile.ZipFile(zip_path)
 assert zipf.testzip() is None,'Bad source CRC'
 names=sorted(n for n in zipf.namelist() if re.match(r'^Cyclic/Raw/test\d+_N(?:min|med|max)_raw\.txt$',n))
 ids=sorted(int(re.search(r'test(\d+)',x).group(1)) for x in names)
 assert ids==list(range(14,41)) and len(names)==27,(ids,len(names))
 phasecache={q:phase_masks(N,q) for q in BUDGETS}
 assert {q:len(p) for q,p in phasecache.items()}=={16:150,32:75,64:75,128:75}
 ledger=[];result1=[];result2=[];phase_smry=[]
 tgrid=np.arange(N)
 theta=2*np.pi*tgrid/N
 basis=np.column_stack([np.ones(N)]+[v for k in range(1,4) for v in [np.sin(k*theta),np.cos(k*theta)]])
 for fn in names:
  test=int(re.search(r'test(\d+)',fn).group(1));grp=(test-14)//3+1
  pressure=re.search(r'_N(min|med|max)_raw',fn).group(1)
  x,f,rec=load_cycle(zipf,fn)
  rec.update(test_id=test,felt_set=grp,pressure=pressure,raw_source_member=fn,segmented_length=N)
  ledger.append(rec)
  rx=float(np.ptp(x));rf=float(np.ptp(f));W=polygon(x,f);coeff=work_coeff(x)
  if abs(W-float(coeff@f))>1e-8*max(1,abs(W)):raise AssertionError('Work linear functional failed')
  # Paper 1: 20% random positions x3 replicates, 10/30% gaps x3 positions
  masks=[]
  for rep in range(3):
   rng=np.random.default_rng(20261109+1000*test+rep)
   hid=np.sort(rng.choice(np.arange(1,N-1),size=int(round(.2*N)),replace=False))
   masks.append(('scattered20',rep,0.20,-1.,hid))
  for frac in (.10,.30):
   L=int(round(frac*N))
   for p in (.15,.50,.85):
    st=1+int(round(p*(N-L-2)))
    masks.append((f'gap{int(frac*100)}',int(p*100),frac,p,np.arange(st,st+L)))
  for category,rep,frac,pos,hid in masks:
   seen=np.ones(N,dtype=bool);seen[hid]=False;idx=np.flatnonzero(seen)
   assert idx[0]==0 and idx[-1]==N-1
   for method in M1:
    xp=interpolate_channel(idx,x[idx],hid,method);fp=interpolate_channel(idx,f[idx],hid,method)
    jn=float(np.sqrt(np.mean((xp-x[hid])**2/rx**2+(fp-f[hid])**2/rf**2)/2))
    fnrmse=float(np.sqrt(np.mean((fp-f[hid])**2))/rf)
    x_c=x.copy();f_c=f.copy();x_c[hid]=xp;f_c[hid]=fp
    area_error=float(abs(polygon(x_c,f_c)-W))
    result1.append(dict(test_id=test,felt_set=grp,pressure=pressure,mask_type=category,mask_rep=rep,mask_fraction=frac,mask_position=pos,missing_count=len(hid),method=method,joint_nrmse=jn,force_nrmse=fnrmse,area_native_abs_kNmm=area_error,area_rel_pct=100*area_error/abs(W),source_W_kNmm=W))
  # Paper 2: 6 matched methods, exact exhaustive rounded uniform-index masks
  for q in BUDGETS:
   scores_for_case={m:[] for m in METHODS}
   for phase_id,(alpha,idx) in enumerate(phasecache[q]):
    y=f[idx]
    scores=[]
    for method,pred in sparse_force_solvers(idx,y,N,basis):
     if not np.isfinite(pred).all():raise ValueError((test,phase_id,q,method))
     What=float(coeff@pred)
     error=abs(What-W)
     rel=100*error/abs(W)
     scores_for_case[method].append(rel)
     # avoid huge csv data by one row per score - source-matched 27*375*6 = 60,750 rows
     scores.append(dict(test_id=test,felt_set=grp,pressure=pressure,q=q,phase_id=phase_id,alpha=alpha,mask_indices_sha256=hashlib.sha256(np.asarray(idx,dtype='<i4').tobytes()).hexdigest(),method=method,observed=q,source_W_kNmm=W,estimated_W_kNmm=What,abs_error_kNmm=error,relative_error_pct=rel))
    assert len(scores)==len(METHODS)
    scores.sort(key=lambda a:(a['relative_error_pct'],METHODS.index(a['method'])))
    margin=scores[1]['relative_error_pct']-scores[0]['relative_error_pct']
    phase_smry.append(dict(test_id=test,felt_set=grp,pressure=pressure,q=q,phase_id=phase_id,alpha=alpha,phase_winner=scores[0]['method'],first_second_margin_pp=margin,best_error_pct=scores[0]['relative_error_pct'],second_error_pct=scores[1]['relative_error_pct']))
    result2.extend(scores)
   for method,vals in scores_for_case.items():
    assert len(vals)==len(phasecache[q])
   print(f'TEST {test:02d} {pressure} group{grp} W={W:.3f} q-families '+','.join(f'{q}:{len(phasecache[q])}' for q in BUDGETS),flush=True)
 ascsv(out/'SOURCE_ADMISSION_AND_CYCLE_LEDGER.csv',ledger)
 ascsv(out/'P1_EUCENTRE_EXTERNAL_MISSINGNESS_RESULTS.csv',result1)
 ascsv(out/'P2_EUCENTRE_EXHAUSTIVE_PHASE_SCORES.csv',result2)
 ascsv(out/'P2_EUCENTRE_PHASE_WINNER_MARGIN.csv',phase_smry)
 method_mean_1=[]
 for task in ['scattered20','gap10','gap30']:
  for method in M1:
   rows=[r for r in result1 if r['mask_type']==task and r['method']==method]
   per_test=[]
   for test in range(14,41):
    arr=[r for r in rows if r['test_id']==test]
    per_test.append(dict(test_id=test,felt_set=(test-14)//3+1,err=float(np.mean([a['joint_nrmse'] for a in arr])),force=float(np.mean([a['force_nrmse'] for a in arr])),area_rel=float(np.mean([a['area_rel_pct'] for a in arr]))))
   values=[p['err'] for p in per_test]
   method_mean_1.append(dict(task=task,method=method,n_cases=len(per_test),n_felt_sets=9,mean_joint_nrmse=float(np.mean(values)),median_joint_nrmse=float(np.median(values)),max_joint_nrmse=float(np.max(values)),mean_force_nrmse=float(np.mean([p['force'] for p in per_test])),mean_area_rel_pct=float(np.mean([p['area_rel'] for p in per_test])),felt_set_equal_mean_joint_nrmse=float(np.mean([np.mean([p['err'] for p in per_test if p['felt_set']==g]) for g in range(1,10)]))))
 ascsv(out/'P1_EUCENTRE_CASE_FIRST_METHOD_SUMMARY.csv',method_mean_1)
 case_results=[];method_summary=[];winner_summary=[]
 for t in range(14,41):
  for q in BUDGETS:
   cands=[]
   for m in METHODS:
    a=[r for r in result2 if r['test_id']==t and r['q']==q and r['method']==m]
    e=np.asarray([x['relative_error_pct'] for x in a])
    cands.append(dict(test_id=t,felt_set=(t-14)//3+1,q=q,method=m,n_phases=len(e),mean_phase_error_pct=float(np.mean(e)),median_phase_error_pct=float(np.median(e)),worst_phase_error_pct=float(np.max(e)),best_phase_error_pct=float(np.min(e)),mean_native_abs_error_kNmm=float(np.mean([x['abs_error_kNmm'] for x in a]))))
   case_results.extend(cands)
   per=[r for r in phase_smry if r['test_id']==t and r['q']==q]
   methods=set(x['phase_winner'] for x in per)
   win=min(cands,key=lambda x:(x['worst_phase_error_pct'],METHODS.index(x['method'])))
   winner_summary.append(dict(test_id=t,felt_set=(t-14)//3+1,q=q,phase_winner_count=len(methods),phase_winner_names=';'.join(sorted(methods)),worst_phase_best_method=win['method'],worst_phase_best_error_pct=win['worst_phase_error_pct'],min_phase_winner_margin_pp=float(min(r['first_second_margin_pp'] for r in per)),median_phase_winner_margin_pp=float(np.median([r['first_second_margin_pp'] for r in per]))))
 ascsv(out/'P2_EUCENTRE_CASE_METHOD_PHASE_AGGREGATES.csv',case_results)
 ascsv(out/'P2_EUCENTRE_CONDITION_BUDGET_WINNERS.csv',winner_summary)
 for q in BUDGETS:
  for m in METHODS:
   a=[r for r in case_results if r['q']==q and r['method']==m]
   worst=np.asarray([r['worst_phase_error_pct'] for r in a]);set_means=[np.mean([r['worst_phase_error_pct'] for r in a if r['felt_set']==g]) for g in range(1,10)]
   method_summary.append(dict(q=q,method=m,n_cases=len(worst),n_felt_sets=9,n_phase_masks=len(phasecache[q]),case_median_worst_phase_pct=float(np.median(worst)),case_mean_worst_phase_pct=float(np.mean(worst)),case_max_worst_phase_pct=float(np.max(worst)),felt_set_equal_mean_worst_phase_pct=float(np.mean(set_means)),felt_set_median_mean_worst_phase_pct=float(np.median(set_means)),case_median_mean_phase_pct=float(np.median([r['mean_phase_error_pct'] for r in a]))))
 ascsv(out/'P2_EUCENTRE_SIX_METHODS_FOUR_BUDGETS.csv',method_summary)
 assert len(result1)==27*9*3 and len(result2)==27*375*6 and len(phase_smry)==27*375
 area_source=np.asarray([r['signed_work_kNmm'] for r in ledger])
 winner_counter={q:int(sum(r['phase_winner_count']>1 for r in winner_summary if r['q']==q)) for q in BUDGETS}
 # source 16 phase nested full-family q=32 summary via original alpha mask identities
 cases_sparse=[]
 for t in range(14,41):
  a32=[r for r in case_results if r['test_id']==t and r['q']==32]
  a128=[r for r in case_results if r['test_id']==t and r['q']==128]
  c32=next(r for r in a32 if r['method']=='cubic')
  h128=next(r for r in a128 if r['method']=='H1')
  cases_sparse.append(dict(test_id=t,comparison='cubic q32 versus H1 q128',cubic32_worst_pct=c32['worst_phase_error_pct'],h1_128_worst_pct=h128['worst_phase_error_pct'],cubic32_better=bool(c32['worst_phase_error_pct']<h128['worst_phase_error_pct'])))
 ascsv(out/'P2_EUCENTRE_CROSS_BUDGET_SOURCE_CONTRAST.csv',cases_sparse)
 summary={
  'release':'EUCENTRE_EXTERNAL_SOURCE_V1','source':'EUCENTRE BED dataset34','source_sha256':SOURCE_DIGEST,
  'pre_outcome_protocol_sha256':checksum(Path(__file__).with_name('FROZEN_EUCENTRE_EXTERNAL_PROTOCOL_v1.md')),
  'n_tests':27,'n_experimental_rigs':1,'n_felt_sets':9,'samples_per_full_loop':N,
  'phase_masks_per_budget':{str(q):len(phasecache[q]) for q in BUDGETS},
  'paper1_n_comparisons':len(result1),'paper2_n_scores':len(result2),
  'paper2_n_phase_winner_observations':len(phase_smry),
  'signed_work_negative_count':int(sum(area_source<0)),
  'min_abs_reference_work_kNmm':float(np.min(abs(area_source))),
  'unstable_phase_winner_condition_budget_count':int(sum(r['phase_winner_count']>1 for r in winner_summary)),
  'unstable_phase_winner_by_budget':winner_counter,
  'cubic32_vs_H1_128_case_wins':int(sum(r['cubic32_better'] for r in cases_sparse)),
  'scope':'Retrospective source-to-result, displacement-defined segmentation; not blind prospective or calibrated friction energy',
  'runtime_seconds':round(time.monotonic()-t0,2)}
 (out/'EUCENTRE_EXTERNAL_VERIFIED_RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('DONE',json.dumps(summary,indent=2))

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True); args=ap.parse_args()
 main(args.source,args.output_dir)
