# R5 source-locked paired processing sensitivity — private derived-only author review

## Inputs

Use separately acquired official BED EUCENTRE dataset 34 `Felt_TestData.zip`, exact SHA256 `060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c`. The original measurement archive and original laboratory report are **not** distributed here. The original q32 Raw scores and cycle provenance CSV files are retrospective author-generated ledgers derived from that dataset. The lab's original processing script, calibration certificates and channel timebase have not been recovered.

## Execution

Within the extracted reproducibility package:

```bash
python -m pip install -r requirements.txt
python r5_paired_raw_processed_q32.py \
  --source /path/to/Felt_TestData.zip \
  --historical-q32 R5_ORIGINAL_Q32_FROZEN_SCORES.csv \
  --frozen-cycle-ledger R5_ORIGINAL_CYCLE_PROVENANCE.csv \
  --out new_output
python r5_independent_verify.py new_output /path/to/Felt_TestData.zip .
```

A results `R5_SUMMARY.json` is generated from the original q32 Raw estimates and new Processed estimates. The exact scientific question is whether recorded-channel processing changes per-phase or worst-phase method choice, **not** which method predicts calibrated interface energy. Processed samples are five-point averages of the dense raw source: q processed points are not equivalent to q independent unprocessed sensor readings.

## Scientific controls

- fixed 27 test IDs, nine reused four-piece felt sets, 2,400-index frozen windows, 75 exact masks at 32 force points, six estimators
- no new model family, no source-specific hyperparameter search, no mask optimization, no inferential p-values from dependent phases
- 12,150 retained Raw scores checked against source identity and mask hash; Processed 12,150 estimates newly computed
- independent validation of all 12,150 numerical percentages and all 2,025 phase winner/rank comparisons; 90 independent estimator spot recomputations
- author-review archive; public rights, author role and DOI release are pending

The PDF/Overleaf revision is SD21 R5 only; Machines E16 remains bitwise-identical to its R4 release.
