#!/usr/bin/env python3
"""R5 SD21 source-identity-gated paired Raw/Processed q32 phase comparison.

New test only: reuses original 12,150 Raw-side historical results, computes the
same six force-only estimators on paired BED Processed columns with the same
frozen raw-cycle indices, 32 actual observed force values and 75 identical
index masks per test. It measures *numerical* work-estimator sensitivity to
archival processing, not metrological accuracy or calibrated dissipation.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, math, sys, zipfile
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
import retained_sd21_eucentre as frozen
SRC_SHA='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c'
METHODS=frozen.METHODS
N=2400

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as r:
  for chunk in iter(lambda:r.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()

def read_csv(p):
 with open(p,encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def write_csv(p,rows):
 assert rows
 with open(p,'w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def stats(vals):
 a=np.array(list(vals),dtype=float)
 return dict(n=int(len(a)),mean=float(a.mean()),median=float(np.median(a)),p90=float(np.percentile(a,90)),min=float(a.min()),max=float(a.max()))

def main():
 pa=argparse.ArgumentParser()
 pa.add_argument('--source',required=True)
 pa.add_argument('--historical-q32',required=True)
 pa.add_argument('--frozen-cycle-ledger',required=True)
 pa.add_argument('--out',required=True)
 p=pa.parse_args(); o=Path(p.out);o.mkdir(exist_ok=True,parents=True)
 assert sha(p.source)==SRC_SHA, 'Source SHA mismatch'
 z=zipfile.ZipFile(p.source); assert z.testzip() is None
 old=read_csv(p.historical_q32)
 assert len(old)==27*75*6 and set(r['method'] for r in old)==set(METHODS)
 assert set(r['q'] for r in old)=={'32'}
 hist={(int(r['test_id']),int(r['phase_id']),r['method']):r for r in old}
 assert len(hist)==len(old)
 cycles={int(r['test_id']):r for r in read_csv(p.frozen_cycle_ledger)}
 assert len(cycles)==27 and sorted(cycles)==list(range(14,41))
 mask=frozen.phase_masks(N,32)
 assert len(mask)==75
 t=np.arange(N);theta=2*np.pi*t/N
 basis=np.column_stack([np.ones(N)]+[vec for k in range(1,4) for vec in [np.sin(k*theta),np.cos(k*theta)]])
 paired=[]; summaries=[];phase_diffs=[]
 for test in range(14,41):
  c=cycles[test]; start=int(c['frozen_cycle_start_index_zero_based']);pres=c['pressure']
  rname=f'Cyclic/Raw/test{test}_{pres}_raw.txt';pname=f'Cyclic/Processed/test{test}_{pres}_processed.txt'
  raw=np.loadtxt(io.BytesIO(z.read(rname)));proc=np.loadtxt(io.BytesIO(z.read(pname)))
  assert raw.shape[1]==2 and proc.shape[1]==2 and start>=0 and start+N<=len(proc)
  r=raw[start:start+N];f=proc[start:start+N]
  raw_w=frozen.polygon(r[:,0],r[:,1]);proc_w=frozen.polygon(f[:,0],f[:,1])
  # Baseline source pairing and preserved source-locked extraction.
  assert math.isclose(raw_w,float(c['raw_cycle_work_kNmm']),rel_tol=1e-12,abs_tol=1e-9)
  assert math.isclose(proc_w,float(c['processed_cycle_work_kNmm']),rel_tol=1e-12,abs_tol=1e-9)
  assert raw_w!=0 and proc_w!=0
  coeff=frozen.work_coeff(f[:,0]); group=int(c['felt_set']);errsR=defaultdict(list);errsP=defaultdict(list)
  transitions=0; phase_l1=[];marginraw=[];marginproc=[]
  for pid,(alpha,idx) in enumerate(mask):
   keyhash=hashlib.sha256(np.asarray(idx,dtype='<i4').tobytes()).hexdigest()
   raw_scores={};proc_scores={}
   for method,pred in frozen.sparse_force_solvers(idx,f[idx,1],N,basis):
    original=hist[(test,pid,method)]
    assert abs(float(original['source_W_kNmm'])-raw_w)<1e-9
    assert original['mask_indices_sha256']==keyhash
    assert abs(float(original['alpha'])-alpha)<1e-12
    estimateP=float(coeff@pred)
    scoreP=abs(estimateP-proc_w)/abs(proc_w)*100
    scoreR=float(original['relative_error_pct'])
    estimateR=float(original['estimated_W_kNmm'])
    errsR[method].append(scoreR);errsP[method].append(scoreP)
    raw_scores[method]=scoreR;proc_scores[method]=scoreP
    paired.append({'test_id':test,'felt_set':group,'pressure':pres,'q':32,'phase_id':pid,'mask_sha256':keyhash,
    'method':method,'raw_reference_work_kNmm':raw_w,'processed_reference_work_kNmm':proc_w,
    'raw_estimate_work_kNmm':estimateR,'processed_estimate_work_kNmm':estimateP,
    'raw_relative_error_pct':scoreR,'processed_relative_error_pct':scoreP,
    'delta_processed_minus_raw_error_pp':scoreP-scoreR,
    'raw_abs_error_kNmm':abs(estimateR-raw_w),'processed_abs_error_kNmm':abs(estimateP-proc_w)})
   rankR=sorted(METHODS,key=lambda m:(raw_scores[m],METHODS.index(m)))
   rankP=sorted(METHODS,key=lambda m:(proc_scores[m],METHODS.index(m)))
   changed=rankR[0]!=rankP[0];transitions+=int(changed)
   marginraw.append(raw_scores[rankR[1]]-raw_scores[rankR[0]])
   marginproc.append(proc_scores[rankP[1]]-proc_scores[rankP[0]])
   phase_diffs.append({'test_id':test,'felt_set':group,'pressure':pres,'phase_id':pid,'raw_winner':rankR[0],
    'processed_winner':rankP[0],'changed_phase_winner':int(changed),
    'raw_best_pct':raw_scores[rankR[0]],'processed_best_pct':proc_scores[rankP[0]],
    'raw_margin_pp':raw_scores[rankR[1]]-raw_scores[rankR[0]],
    'processed_margin_pp':proc_scores[rankP[1]]-proc_scores[rankP[0]],
    'raw_vs_processed_ranking_unchanged':int(rankR==rankP)})
  assert len(errsP)==len(METHODS) and all(len(v)==75 for v in errsP.values())
  rankingR=sorted(METHODS,key=lambda m:(max(errsR[m]),METHODS.index(m)))
  rankingP=sorted(METHODS,key=lambda m:(max(errsP[m]),METHODS.index(m)))
  for method in METHODS:
   summaries.append({'test_id':test,'felt_set':group,'pressure':pres,'method':method,'q':32,'n_phase_masks':75,
    'raw_worst_phase_error_pct':max(errsR[method]),'processed_worst_phase_error_pct':max(errsP[method]),
    'raw_median_phase_error_pct':float(np.median(errsR[method])),
    'processed_median_phase_error_pct':float(np.median(errsP[method])),
    'raw_mean_phase_error_pct':float(np.mean(errsR[method])),
    'processed_mean_phase_error_pct':float(np.mean(errsP[method])),
    'raw_is_worst_phase_winner':int(method==rankingR[0]),
    'processed_is_worst_phase_winner':int(method==rankingP[0]),
    'case_phase_winner_changed_count':transitions,
    'case_worst_phase_best_changed':int(rankingR[0]!=rankingP[0])})
  print(f'Test {test} set {group} W(Raw)={raw_w:.4f} W(Proc)={proc_w:.4f} changed phase winners={transitions}/75, worst-choice {rankingR[0]}->{rankingP[0]}',flush=True)
 assert len(paired)==12150 and len(phase_diffs)==2025 and len(summaries)==162
 by_test=[];by_group=[]
 for t in range(14,41):
  ph=[r for r in phase_diffs if r['test_id']==t]
  by_test.append({'test_id':t,'felt_set':(t-14)//3+1,'n_phases':75,
   'phase_winner_changes':sum(r['changed_phase_winner'] for r in ph),
   'all_rank_order_changes':sum(1-r['raw_vs_processed_ranking_unchanged'] for r in ph),
   'worst_phase_winner_changes':int(summaries[6*(t-14)]['case_worst_phase_best_changed'])})
 for group in range(1,10):
  sub=[r for r in by_test if r['felt_set']==group]
  by_group.append({'felt_set':group,'n_tests':3,
    'phase_winner_changes':sum(r['phase_winner_changes'] for r in sub),
    'phase_winner_change_fraction':sum(r['phase_winner_changes'] for r in sub)/(3*75),
    'test_level_worst_phase_winner_changes':sum(r['worst_phase_winner_changes'] for r in sub)})
 per_method=[]
 for m in METHODS:
  sub=[r for r in summaries if r['method']==m]
  raw_worst=[r['raw_worst_phase_error_pct'] for r in sub];pr_worst=[r['processed_worst_phase_error_pct'] for r in sub]
  per_method.append({'method':m,'n_tests':27,'n_independent_felt_sets':9,
   'raw_case_median_worst_pct':float(np.median(raw_worst)),
   'proc_case_median_worst_pct':float(np.median(pr_worst)),
   'raw_case_mean_worst_pct':float(np.mean(raw_worst)),
   'proc_case_mean_worst_pct':float(np.mean(pr_worst)),
   'raw_case_max_worst_pct':float(np.max(raw_worst)),
   'proc_case_max_worst_pct':float(np.max(pr_worst)),
   'median_abs_worst_difference_pp':float(np.median(abs(np.array(pr_worst)-np.array(raw_worst)))),
   'raw_case_winner_n':int(sum(r['raw_is_worst_phase_winner'] for r in sub)),
   'proc_case_winner_n':int(sum(r['processed_is_worst_phase_winner'] for r in sub))})
 summary={
 'status':'SOURCE_MATCHED_ADDITIONAL_PROCESSING_SENSITIVITY; NOT NEW INSTRUMENT_CALIBRATION',
 'original_raw_results_reused_not_recalculated':True,'source_sha256':SRC_SHA,
 'source_tests':27,'physical_groups':9,'q':32,'masks_per_test':75,'methods':list(METHODS),
 'raw_scores_from_retained_original_ledger':12150,'processed_scores_recalculated':12150,
 'paired_scenarios':2025,'phase_winner_changes':int(sum(r['changed_phase_winner'] for r in phase_diffs)),
 'phase_winner_change_pct':float(100*np.mean([r['changed_phase_winner'] for r in phase_diffs])),
 'any_ranking_change_masks':int(sum(1-r['raw_vs_processed_ranking_unchanged'] for r in phase_diffs)),
 'test_worst_phase_winner_changes':int(sum(r['worst_phase_winner_changes'] for r in by_test)),
 'n_tests_any_phase_winner_change':int(sum(r['phase_winner_changes']>0 for r in by_test)),
 'n_groups_any_phase_winner_change':int(sum(r['phase_winner_changes']>0 for r in by_group)),
 'change_fraction_by_nine_felt_sets':stats(r['phase_winner_change_fraction'] for r in by_group),
 'phase_changed_count_by_test':stats(r['phase_winner_changes'] for r in by_test),
 'original_estimator_q32_same_phase_and_mask':True,
 'raw_processed_source_columns_both_change':True,
 'sampling_rate_and_calibration_undocumented':True,
 'correlated_mask_and_specimen_reuse_not_independent':True,
 'submission_status':'PRIVATE_DESCRIPTIVE_POST_OUTCOME_AUDIT'
 }
 for name,rows in [('R5_PAIRED_Q32_ALL_SCORES.csv',paired),('R5_PAIRED_Q32_PHASE_WINNERS.csv',phase_diffs),
 ('R5_PAIRED_Q32_CASE_METHOD_WORST.csv',summaries),('R5_TEST_FIRST_SUMMARY.csv',by_test),
 ('R5_FELT_SET_FIRST_SUMMARY.csv',by_group),('R5_Q32_METHOD_SUMMARY.csv',per_method)]: write_csv(o/name,rows)
 (o/'R5_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
 print('DONE',json.dumps(summary,indent=2))
if __name__=='__main__':main()
