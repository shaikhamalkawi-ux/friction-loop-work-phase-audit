#!/usr/bin/env python3
"""Independent aggregation, polygon and selected estimator checks for R5.
Does not use R5 main script internals.  Validates one full paired ledger and
native closed trapezoids; sampled source paths are computed independently.
"""
import csv,hashlib,io,json,zipfile,sys,math
from pathlib import Path
from collections import Counter
import numpy as np
from scipy.interpolate import CubicSpline,PchipInterpolator
p=Path(sys.argv[1]);src=Path(sys.argv[2]);root=Path(sys.argv[3]);srcdigest='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c'
assert hashlib.sha256(src.read_bytes()).hexdigest()==srcdigest
read=lambda n:list(csv.DictReader(open(p/n,newline='')))
scores=read('R5_PAIRED_Q32_ALL_SCORES.csv');phases=read('R5_PAIRED_Q32_PHASE_WINNERS.csv');cases=read('R5_PAIRED_Q32_CASE_METHOD_WORST.csv'); s=json.loads((p/'R5_SUMMARY.json').read_text())
assert len(scores)==12150 and len(phases)==2025 and len(cases)==162
bycase={}
for row in scores:
 key=int(row['test_id']),int(row['phase_id']);bycase.setdefault(key,{})[row['method']]=row
assert len(bycase)==2025 and all(len(x)==6 for x in bycase.values())
methods=('H1','H3','linear','pchip','cubic','nearest')
max_id=0.0;changed=0;rankchanged=0;worst_mismatch=0
for key,rows in bycase.items():
 for r in rows.values():
  for typ in ['raw','processed']:
   w=float(r[f'{typ}_reference_work_kNmm']); pred=float(r[f'{typ}_estimate_work_kNmm']); err=float(r[f'{typ}_relative_error_pct']);
   discrepancy=abs(100*abs(pred-w)/abs(w)-err);max_id=max(max_id,discrepancy)
   assert discrepancy<1e-10
  assert abs((float(r['processed_relative_error_pct'])-float(r['raw_relative_error_pct']))-float(r['delta_processed_minus_raw_error_pp']))<1e-10
 ar=sorted(methods,key=lambda m:(float(rows[m]['raw_relative_error_pct']),methods.index(m)))
 ap=sorted(methods,key=lambda m:(float(rows[m]['processed_relative_error_pct']),methods.index(m)))
 changed+=ar[0]!=ap[0];rankchanged+=ar!=ap
rowmap={(int(x['test_id']),int(x['phase_id'])):x for x in phases}
for k,rows in bycase.items():
 r=rowmap[k];ar=sorted(methods,key=lambda m:(float(rows[m]['raw_relative_error_pct']),methods.index(m)))
 ap=sorted(methods,key=lambda m:(float(rows[m]['processed_relative_error_pct']),methods.index(m)))
 assert r['raw_winner']==ar[0] and r['processed_winner']==ap[0]
assert changed==143 and rankchanged==300 and max_id<1e-10
for t in range(14,41):
 chosen=[]
 for ty in ['raw','processed']:
  w={m:max(float(bycase[t,k][m][f'{ty}_relative_error_pct']) for k in range(75)) for m in methods}
  chosen.append(min(methods,key=lambda m:(w[m],methods.index(m))))
 assert chosen==['cubic','cubic']
# Check full dense processed polygon with independent explicit seam/trapezoid on 27 original record boundaries.
z=zipfile.ZipFile(src); cycle={int(r['test_id']):r for r in csv.DictReader(open(root/'R5_ORIGINAL_CYCLE_PROVENANCE.csv'))}
max_polygon=0.0;max_independent_recompute=0.0; spot=[]
for t in range(14,41):
 c=cycle[t]; f=f'Cyclic/Processed/test{t}_{c["pressure"]}_processed.txt'; a=np.loadtxt(io.BytesIO(z.read(f))); i=int(c['frozen_cycle_start_index_zero_based']); x,y=a[i:i+2400].T
 w=float(np.sum(0.5*(y[1:]+y[:-1])*np.diff(x)) + (y[-1]+y[0])*(x[0]-x[-1])*0.5)
 wa=float(next(r for r in scores if int(r['test_id'])==t)['processed_reference_work_kNmm'])
 max_polygon=max(max_polygon,abs(w-wa));assert abs(w-wa)<1e-8
# Orthogonal selected estimator path (5 tests x 3 masks x 6 estimators): least-square SVD via pinv,
# scipy interpolators invoked directly from sampled indices. No R5 implementation imported.
for t in [14,20,27,35,40]:
 c=cycle[t];a=np.loadtxt(io.BytesIO(z.read(f'Cyclic/Processed/test{t}_{c["pressure"]}_processed.txt')));i=int(c['frozen_cycle_start_index_zero_based']);x,y=a[i:i+2400].T
 grid=np.arange(2400);co=(np.roll(x,-1)-np.roll(x,1))*.5
 theta=2*np.pi*grid/2400
 for pid in [0,35,74]:
  # reconstruct source registered mask from exact decimal rational transition alpha
  alpha=float(next(r for r in scores if int(r['test_id'])==t and int(r['phase_id'])==pid)['raw_relative_error_pct']) if False else None
  rows=bycase[t,pid]
  # historical q32 index masks can be derived from generated sorted rational boundaries
  from fractions import Fraction
  b=sorted(set(Fraction((2*j+1)*32,2*2400)%1 for j in range(2400)))
  lower=b[pid];upper=b[pid+1] if pid<74 else b[0]+1
  aphase=float((lower+upper)/2%1)
  ix=np.sort(np.floor(2400*(np.arange(32)+aphase)/32+0.5).astype(int)%2400)
  yf=y[ix];res={}
  ext=np.r_[ix[-1]-2400,ix,ix[0]+2400];fext=np.r_[yf[-1],yf,yf[0]]
  res['linear']=np.interp(grid,ext,fext)
  res['pchip']=PchipInterpolator(np.r_[ix-2400,ix,ix+2400],np.tile(yf,3))(grid)
  ixp=np.r_[ix,ix[0]+2400];vp=np.r_[yf,yf[0]];g=np.where(grid<ix[0],grid+2400,grid)
  res['cubic']=CubicSpline(ixp,vp,bc_type='periodic')(g)
  dl=(grid[:,None]-ix[None,:])%2400;dr=(ix[None,:]-grid[:,None])%2400
  mind=np.minimum(dl,dr);j=np.argmin(mind,axis=1);res['nearest']=yf[j]
  # tie at midpoints needs to prefer lower numeric source index, adjust for exact boundary tie
  for i_grid in range(2400):
   d=np.minimum((grid[i_grid]-ix)%2400,(ix-grid[i_grid])%2400);min_d=d.min();cs=np.where(d==min_d)[0]
   if len(cs)>1:res['nearest'][i_grid]=yf[cs[np.argmin(ix[cs])]]
  for nh,m in [(1,'H1'),(3,'H3')]:
   X=np.column_stack([np.ones(2400)]+[v for k in range(1,nh+1) for v in [np.sin(k*theta),np.cos(k*theta)]])
   res[m]=X@(np.linalg.pinv(X[ix])@yf)
  for m in methods:
   guess=float(co@res[m]); historic=float(rows[m]['processed_estimate_work_kNmm'])
   d=abs(guess-historic);max_independent_recompute=max(max_independent_recompute,d)
   if d>1e-7:raise AssertionError((t,pid,m,d,guess,historic))
  spot.append((t,pid))
report={'source_sha_pass':True,'all_12150_processed_score_identities_pass':True,'max_abs_score_identity_pp':max_id,
 'full_2025_phase_winners_checked':True,'confirmed_phase_winner_changes':changed,'confirmed_full_rank_changes':rankchanged,
 'confirmed_worst_phase_method_winner_on_27_tests':'cubic all Raw and Processed',
 'raw_or_processed_paired_ranges_are_not_32_independent_raw_sensor_readings':True,
 '27_dense_processed_polygons_replayed':True,'max_abs_dense_reference_residual_kNmm':max_polygon,
 'independently_recomputed_spot_predictions':len(spot)*len(methods),'max_abs_spot_estimator_work_residual_kNmm':max_independent_recompute,
 'scope':'source-conditional descriptive, no independent sensor calibration, not lab software provenance','status':'PASS'}
(root/'R5_INDEPENDENT_VERIFY.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
