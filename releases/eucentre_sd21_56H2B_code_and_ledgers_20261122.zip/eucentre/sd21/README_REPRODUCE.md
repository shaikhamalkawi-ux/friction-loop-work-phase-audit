# H2 E15 + SD21 — external source reproducibility, source-locked

## Verified scope
Separate reference-compatible journal manuscripts: **Machines E15** (paired force + displacement missing-data geometry) and **Numerical Work SD21** (sparse force, full displacement, recorded polygonal actuator work). New source: Brunesi et al., *Friction characterisation testing of fabric felt material used in pre-cast structures*, BED Experiments V1, DOI: https://doi.org/10.60756/euc-ubsy26g318. Related study: https://doi.org/10.1002/suco.201900069. BED platform DOI: https://doi.org/10.1002/eqe.4231.

The 27 new test records are 9 reused felt sets within ONE experimental apparatus; 2017 original test, source release 2026. Do not pool with the 27 previously used Fantetti/Imperial conditions. This archive is derived-only; no original external source bytes are distributed.

## Source requirement
Download the provider's **original** `Felt_TestData.zip` (47,018,649 bytes). SHA-256 must be:

`060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c`

A wrong or missing source ZIP stops the execution, never substitutes prior derived scores. Do not unzip source into the journal submission package. The source ZIP includes original channels (x in mm and actuator F in kN) and 364-page technical report with separate branding/reproduction notes. The dataset's portal license is CC BY 4.0; attribute original provider, and do not silently redistribute the historical report.

## Tested numerical dependencies
Python 3.13 with NumPy, SciPy, pandas, and matplotlib. Exact versions in `ENVIRONMENT_TESTED.json`; `requirements.txt` lists compatible dependency constraints. Floating point can vary by CPU and library; interpret maximum residuals numerically rather than demanding file-level bit identity on all platforms.

## One-command source-to-result chain
From the top level of the external-reproducibility ZIP, after installing dependencies:

```bash
python -m pip install -r requirements.txt
python run_eucentre_external_locked_v1.py --source /your/provider/Felt_TestData.zip --output-dir RESULTS_FRESH
python build_external_science_and_figures.py --source /your/provider/Felt_TestData.zip --result-dir RESULTS_FRESH --figure-dir FIGURES_FRESH
python independent_verify_eucentre_v1.py --source /your/provider/Felt_TestData.zip --result-dir RESULTS_FRESH --report INDEPENDENT_FRESH.json
```

The first program checks original ZIP SHA/CRC, test identities, cycles and masks, produces all P1/P2 scores and core aggregates. The second produces nested 16-versus-complete masks, closing-edge sensitivity and four vector figures. The third uses a separate scoring implementation; it recomputes 729 P1 scores, 1,944 sampled P2 predictions, all 60,750 score identities, all 10,125 winner margins and full rational phase masks.

## Published-scope outputs and QA
The `RESULTS` folder is the fixed output from the original source. `CLEAN_REPLAY_SHA256_PARITY.json` proves 9/9 primary CSV outputs byte-identical in a fresh rerun under the tested environment (the timing field in summary JSON is deliberately not asserted byte-identical). `INDEPENDENT_EUCENTRE_VERIFICATION.json` is the standalone mathematical/source audit. `FROZEN_EUCENTRE_EXTERNAL_PROTOCOL_v1.md` preserves the pre-performance protocol hash. The 16-phase and exhaustive rank/audit summaries and absolute-work closure sensitivity are in derivative CSVs.

**No raw provider data are included**, no calibrated timing error is computed, and the 2400-index period is not an acquisition rate. Provenance and restrictions are documented in `RESEARCH_DECISION_AR.md` and `INDEPENDENT_EXTERNAL_REVIEW_EN.md`.

## Manuscript source reproducibility
Each paper has a self-contained Overleaf-ready source ZIP with its journal class/figures. Extract and run `pdflatex -interaction=nonstopmode -halt-on-error main.tex` three times, likewise `supplement.tex`. The combined PDF concatenates the main manuscript and the corresponding supplementary PDF in that order.

## Version/author boundaries
This is a scientific extension of E14/SD20; earlier numerical results are unchanged. This code/material is a prepared author-review delivery; author approval, CRediT/funding/conflicts statements, overlap declarations and repository DOI/licence must be verified before publication. Neither new source nor existing prior-run code should be published publicly on GitHub automatically.
