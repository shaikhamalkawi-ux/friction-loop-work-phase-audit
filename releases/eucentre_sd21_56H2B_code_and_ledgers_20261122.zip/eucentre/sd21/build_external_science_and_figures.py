from pathlib import Path
import argparse
import sys, json, io, zipfile, math, hashlib
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
import matplotlib.pyplot as plt
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True,help='Original provider Felt_TestData.zip')
parser.add_argument('--result-dir',type=Path,default=Path(__file__).resolve().parent/'RESULTS')
parser.add_argument('--figure-dir',type=Path,default=Path(__file__).resolve().parent/'FIGURES')
args=parser.parse_args()
ROOT=Path(__file__).resolve().parent;res=args.result_dir;fig=args.figure_dir;fig.mkdir(exist_ok=True)
p1=pd.read_csv(res/'P1_EUCENTRE_EXTERNAL_MISSINGNESS_RESULTS.csv')
p2=pd.read_csv(res/'P2_EUCENTRE_EXHAUSTIVE_PHASE_SCORES.csv')
agg1=pd.read_csv(res/'P1_EUCENTRE_CASE_FIRST_METHOD_SUMMARY.csv')
agg2=pd.read_csv(res/'P2_EUCENTRE_SIX_METHODS_FOUR_BUDGETS.csv')
win=pd.read_csv(res/'P2_EUCENTRE_PHASE_WINNER_MARGIN.csv')
cases=pd.read_csv(res/'P2_EUCENTRE_CASE_METHOD_PHASE_AGGREGATES.csv')
sreg=pd.read_csv(res/'SOURCE_ADMISSION_AND_CYCLE_LEDGER.csv')

# supplementary source operator/closure check; no physical error model or unmeasured timing claimed
z=zipfile.ZipFile(args.source);closure=[]
for r in sreg.itertuples():
 a=np.loadtxt(io.BytesIO(z.read(r.raw_source_member)),dtype=float);a=a[int(r.first_peak_index):int(r.first_peak_index)+2400]
 x,f=a.T; openW=float(.5*np.sum((f[1:]+f[:-1])*(x[1:]-x[:-1])))
 edge=float(.5*(f[0]+f[-1])*(x[0]-x[-1])); closedW=openW+edge
 assert abs(closedW-r.signed_work_kNmm)<1e-9
 closure.append(dict(test_id=r.test_id,felt_set=r.felt_set,open_path_work_kNmm=openW,closing_edge_work_kNmm=edge,closed_polygon_work_kNmm=closedW,closing_edge_abs_fraction_pct=100*abs(edge)/abs(closedW),cycle_end_to_start_displacement_mm=float(x[0]-x[-1]),cycle_end_to_start_force_kN=float(f[0]-f[-1])))
pd.DataFrame(closure).to_csv(res/'EUCENTRE_OPEN_VS_CLOSED_CYCLE_AUDIT.csv',index=False)

# exact 16 original phase family as a subset of exhaustive stage; all scores already computed and frozen
masks16={}
for q in [16,32,64,128]:
 ids=[]
 for s in range(16):
  ind=np.sort(np.floor(2400*(np.arange(q)+s/16)/q+0.5-1e-11).astype(int)%2400)
  ids.append(hashlib.sha256(np.asarray(ind,dtype='<i4').tobytes()).hexdigest())
 masks16[q]=set(ids)
 subset=p2[(p2.q==q)&p2.mask_indices_sha256.isin(masks16[q])]
 assert subset.groupby(['test_id','q','method']).size().eq(16).all(),(q,len(subset))
 if q==16: reduced=subset.copy()
 else: reduced=pd.concat([reduced,subset],ignore_index=True)
phase16=reduced.groupby(['test_id','felt_set','q','method']).relative_error_pct.max().rename('worst_of_16_pct').reset_index()
full75=cases[['test_id','felt_set','q','method','worst_phase_error_pct']]
a=phase16.merge(full75,on=['test_id','felt_set','q','method'],validate='one_to_one');a['exhaustive_minus_16_pp']=a['worst_phase_error_pct']-a['worst_of_16_pct'];assert (a.exhaustive_minus_16_pp>-1e-9).all()
a.to_csv(res/'P2_EUCENTRE_16_VERSUS_EXHAUSTIVE_CASE_LEVEL.csv',index=False)
case16=a.sort_values(['test_id','q','worst_of_16_pct','method']).groupby(['test_id','q']).first().reset_index()[['test_id','q','method']].rename(columns={'method':'winner16'})
caseAll=a.sort_values(['test_id','q','worst_phase_error_pct','method']).groupby(['test_id','q']).first().reset_index()[['test_id','q','method']].rename(columns={'method':'winner_full'})
comp=case16.merge(caseAll,on=['test_id','q']);comp['changed']=comp.winner16!=comp.winner_full
comp.to_csv(res/'P2_EUCENTRE_16_VERSUS_EXHAUSTIVE_WINNER_CHANGE.csv',index=False)

# Original phase family vs exact full family cross-budget historical pair
cross=[]
for test in range(14,41):
 cc=a[(a.test_id==test)&(a.q==32)&(a.method=='cubic')].iloc[0];h=a[(a.test_id==test)&(a.q==128)&(a.method=='H1')].iloc[0]
 cross.append({'test_id':test,'cubic32_16_pct':cc.worst_of_16_pct,'h1_128_16_pct':h.worst_of_16_pct,'cubic32_exhaustive_pct':cc.worst_phase_error_pct,'h1_128_exhaustive_pct':h.worst_phase_error_pct,'cubic32_win16':bool(cc.worst_of_16_pct<h.worst_of_16_pct),'cubic32_win_exhaustive':bool(cc.worst_phase_error_pct<h.worst_phase_error_pct)})
pd.DataFrame(cross).to_csv(res/'P2_EUCENTRE_CROSS_BUDGET_16_AND_FULL.csv',index=False)

# visualization 1: case-first mean joint RMSE 3 tasks 3 methods
fig1,ax=plt.subplots(figsize=(7.8,3.6));methods=['linear','pchip','natural_cubic'];tasks=['scattered20','gap10','gap30']; xloc=np.arange(3);w=0.23
for j,m in enumerate(methods):
 vals=[float(agg1[(agg1.task==task)&(agg1.method==m)].mean_joint_nrmse.iloc[0]) for task in tasks]
 ax.bar(xloc+(j-1)*w,vals,width=w,label={'linear':'Linear','pchip':'PCHIP','natural_cubic':'Natural cubic'}[m])
ax.set_yscale('log');ax.set_ylim(0.005,4.5);ax.set_xticks(xloc, ['Scattered 20%','Contiguous gap 10%','Contiguous gap 30%']);ax.set_ylabel('Mean case-first joint NRMSE (log scale)');ax.legend(loc='upper left',ncol=3,fontsize=8);ax.grid(axis='y',alpha=.25)
fig1.tight_layout();fig1.savefig(fig/'E15_EUCENTRE_PointVsGap_External.pdf');plt.close(fig1)

# visualization 2: paired 27 case results natural-cubic vs PCHIP under gap30, not pooled windows
pp=p1[p1.mask_type=='gap30'].groupby(['test_id','method']).joint_nrmse.mean().unstack()
fig2,ax=plt.subplots(figsize=(7.5,3.2));ax.scatter(pp.pchip,pp.natural_cubic,s=28,alpha=.9)
lo=min(pp.min().min(),.001);hi=max(pp.max().max(),1.)
ax.plot([lo,hi],[lo,hi],ls='--',lw=1,color='gray');ax.set_xlabel('PCHIP: case-mean joint NRMSE');ax.set_ylabel('Natural cubic: case-mean joint NRMSE');ax.set_xscale('log');ax.set_yscale('log');ax.set_ylim(.02,5);ax.set_xlim(.02,5);ax.grid(alpha=.25)
fig2.tight_layout();fig2.savefig(fig/'E15_EUCENTRE_Gap30_27CasePaired.pdf');plt.close(fig2)

# visualization 3: external six-method worst phase mean and median at four q
fig3,(a1,a2)=plt.subplots(1,2,figsize=(9.1,3.8),sharey=True)
for m in ['H1','H3','linear','pchip','cubic','nearest']:
 a=agg2[agg2.method==m].sort_values('q')
 a1.plot(a.q,a.case_median_worst_phase_pct,'o-',label=m,ms=3)
 a2.plot(a.q,a.case_mean_worst_phase_pct,'o-',label=m,ms=3)
for ax,title in [(a1,'Median of 27 test-level worst phases'),(a2,'Mean of 27 test-level worst phases')]:
 ax.set_title(title,fontsize=10);ax.set_yscale('log');ax.set_xlabel('Observed force points per loop (q)');ax.set_xticks([16,32,64,128]);ax.grid(alpha=.3)
a1.set_ylabel('Relative numerical-work error (%)');a2.legend(loc='upper right',fontsize=7,ncol=2);fig3.tight_layout();fig3.savefig(fig/'SD21_EUCENTRE_Exhaustive_SixMethods.pdf');plt.close(fig3)

# visualization 4: source-independent fdelta margin only analysis distribution
fig4,ax=plt.subplots(figsize=(7.5,3.2));dat=[win[win.q==q].first_second_margin_pp.to_numpy() for q in [16,32,64,128]]
ax.boxplot(dat,tick_labels=['16','32','64','128'],showfliers=False);ax.set_yscale('log');ax.set_xlabel('Force observation budget q');ax.set_ylabel('First-to-second phase error margin (pp)');ax.set_title('Within-phase winner margins, 27 tests × all admissible masks');ax.grid(axis='y',alpha=.3)
fig4.tight_layout();fig4.savefig(fig/'SD21_EUCENTRE_Phase_Winner_Margins.pdf');plt.close(fig4)

# summary with counts, descriptive checks (not confidence probabilities)
summary={
 'P1_case_winners':{task:p1[p1.mask_type==task].groupby(['test_id','method']).joint_nrmse.mean().unstack().idxmin(axis=1).value_counts().to_dict() for task in tasks},
 'P2_worst_phase_winner':{str(q):cases[cases.q==q].loc[cases[cases.q==q].groupby('test_id').worst_phase_error_pct.idxmin(),'method'].value_counts().to_dict() for q in [16,32,64,128]},
 'P2_case_q_winner_changes_16_vs_complete':int(comp.changed.sum()),
 'P2_case_q_winner_changes_by_q':{str(q):int(comp[comp.q==q].changed.sum()) for q in [16,32,64,128]},
 'P2_Cubic32_better_than_H1_128_16':int(sum(x['cubic32_win16'] for x in cross)),
 'P2_Cubic32_better_than_H1_128_full':int(sum(x['cubic32_win_exhaustive'] for x in cross)),
 'P2_phase_winner_margins':{str(q):{'median_pp':float(np.median(win[win.q==q].first_second_margin_pp)), 'p90_pp':float(np.quantile(win[win.q==q].first_second_margin_pp,.9))} for q in [16,32,64,128]},
 'source_closure_edge_fraction_pct_max':float(max(x['closing_edge_abs_fraction_pct'] for x in closure)),
 'source_closure_edge_fraction_pct_median':float(np.median([x['closing_edge_abs_fraction_pct'] for x in closure])),
 'source_closure_gap_mm_max':float(max(abs(x['cycle_end_to_start_displacement_mm']) for x in closure)),
 'source_closure_work_gap_native_max':float(max(abs(x['closing_edge_work_kNmm']) for x in closure))}
(res/'EUCENTRE_EXTERNAL_SECONDARY_DESCRIPTIVES.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
