#!/usr/bin/env python3
"""Author-independent reimplementation/checker for frozen external source ledgers.
Do not import or call primary runner numerical kernels.
"""
from pathlib import Path
import argparse
from collections import defaultdict
from fractions import Fraction
import json,csv,io,zipfile,hashlib,math,numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator
from scipy.signal import find_peaks
from scipy.ndimage import median_filter
import pandas as pd
parser=argparse.ArgumentParser()
parser.add_argument('--source',required=True,type=Path,help='Original provider Felt_TestData.zip')
parser.add_argument('--result-dir',type=Path,default=Path(__file__).resolve().parent/'RESULTS')
parser.add_argument('--report',type=Path,default=Path(__file__).resolve().parent/'INDEPENDENT_EUCENTRE_VERIFICATION.json')
args=parser.parse_args()
P=Path(__file__).resolve().parent; ROOT=args.result_dir
raw_zip=args.source
RESULT={}
def must(b,key):
 RESULT[key]=bool(b)
 if not b:raise AssertionError(key)

src=zipfile.ZipFile(raw_zip); must(src.testzip() is None,'ZIP_CRC')
must(hashlib.sha256(raw_zip.read_bytes()).hexdigest()=='060ebde9178e1309c340f6af0e16991e45ba6a4d7abbdc423aed48f2c73ebf5c','SOURCE_SHA')
ledger=pd.read_csv(ROOT/'SOURCE_ADMISSION_AND_CYCLE_LEDGER.csv');p1=pd.read_csv(ROOT/'P1_EUCENTRE_EXTERNAL_MISSINGNESS_RESULTS.csv');p2=pd.read_csv(ROOT/'P2_EUCENTRE_EXHAUSTIVE_PHASE_SCORES.csv');wins=pd.read_csv(ROOT/'P2_EUCENTRE_PHASE_WINNER_MARGIN.csv');summ=pd.read_csv(ROOT/'P2_EUCENTRE_SIX_METHODS_FOUR_BUDGETS.csv'); p1summ=pd.read_csv(ROOT/'P1_EUCENTRE_CASE_FIRST_METHOD_SUMMARY.csv'); cagg=pd.read_csv(ROOT/'P2_EUCENTRE_CASE_METHOD_PHASE_AGGREGATES.csv')
must(len(ledger)==27 and len(p1)==729 and len(p2)==60750 and len(wins)==10125,'EXPECTED_CARDINALITIES')
must(set(ledger.test_id)==set(range(14,41)),'COMPLETE_SOURCE_COHORT')
must(set(ledger.felt_set)==set(range(1,10)) and ledger.groupby('felt_set').size().eq(3).all(),'NESTED_FELT_SETS')
must(all(p1.groupby(['test_id','mask_type','mask_rep']).size()==3),'EQUAL_INTERPOLATOR_CONTRACT')
must(all(p2.groupby(['test_id','q','phase_id']).size()==6),'SIX_METHODS_PER_MASK')
must(all(p2.groupby(['test_id','q','method']).size().isin([75,150])),'PHASE_COUNTS')
must(all(p2.groupby('q').phase_id.nunique().eq(pd.Series({16:150,32:75,64:75,128:75}))), 'FULL_PHASE_ENUM_COUNTS')
must((p2.relative_error_pct>=0).all() and p2.relative_error_pct.notna().all(),'NONNEGATIVE_FINITE_ERRORS')
must((p1.joint_nrmse>=0).all() and p1.joint_nrmse.notna().all(),'FINITE_P1_ERRORS')
# recompute 27 recorded dense polygon values by TWO distinct forms, at fixed displaced cycle bounds from registered file
sources={}
max_gap_polygon_dot=0
max_source_stored_work_abs=0
for r in ledger.itertuples():
 raw=np.loadtxt(io.BytesIO(src.read(r.raw_source_member)))
 x=raw[r.first_peak_index:r.first_peak_index+2400,0];f=raw[r.first_peak_index:r.first_peak_index+2400,1]
 assert len(x)==2400
 # independent direct line formula and source dot-form weights, verifying oriented closure
 poly=.5*sum((f[i]+f[(i+1)%2400])*(x[(i+1)%2400]-x[i]) for i in range(2400))
 c=(np.roll(x,-1)-np.roll(x,1))/2
 W=float(np.dot(c,f))
 max_gap_polygon_dot=max(max_gap_polygon_dot,abs(poly-W))
 max_source_stored_work_abs=max(max_source_stored_work_abs,abs(W-r.signed_work_kNmm))
 must(np.ptp(x)>55 and abs(W)>1e-8 and abs(raw[r.first_peak_index+2400,0]-x[0])<.5,'SOURCE_SEGMENT_GUARDS')
 sources[r.test_id]=(x,f,c,W)
must(max_gap_polygon_dot<1e-9,'INDEPENDENT_POLYGON_IDENTITY')
must(max_source_stored_work_abs<1e-9,'DENSE_SOURCE_WORK_REPRODUCTION')

# independent P1 computation for all 729 rows; all seen masks source-defined, no cherry picking
max_p1_joint_delta=0; max_p1_absdelta=0
for r in p1.itertuples():
 x,f,c,W=sources[r.test_id]; n=len(x)
 if r.mask_type=='scattered20':
  rng=np.random.default_rng(20261109+1000*r.test_id+int(r.mask_rep))
  hold=np.sort(rng.choice(np.arange(1,n-1),size=480,replace=False))
 else:
  L=int(round(float(r.mask_fraction)*2400));st=1+int(round(float(r.mask_position)*(2400-L-2)))
  hold=np.arange(st,st+L)
 seen=np.ones(n,bool);seen[hold]=False;training=np.where(seen)[0]
 preds=[]
 for y in [x,f]:
  if r.method=='linear': yp=np.interp(hold,training,y[seen])
  elif r.method=='pchip':yp=PchipInterpolator(training,y[seen])(hold)
  elif r.method=='natural_cubic':yp=CubicSpline(training,y[seen],bc_type='natural')(hold)
  preds.append(yp)
 ee=((preds[0]-x[hold])/np.ptp(x))**2+((preds[1]-f[hold])/np.ptp(f))**2
 score=float(np.sqrt(np.mean(ee)/2))
 max_p1_joint_delta=max(max_p1_joint_delta,abs(score-r.joint_nrmse))
 xc=x.copy();fc=f.copy();xc[hold]=preds[0];fc[hold]=preds[1]
 Wp=.5*np.sum((fc+np.roll(fc,-1))*(np.roll(xc,-1)-xc))
 max_p1_absdelta=max(max_p1_absdelta,abs(abs(Wp-W)-r.area_native_abs_kNmm))
must(max_p1_joint_delta<2e-12 and max_p1_absdelta<1e-8,'P1_FULL_RECOMPUTATION_729')

# independent full phase set by first principles for n=2400, not reading primary's transition code
masks={}
for q in (16,32,64,128):
 # solve all q*N possible boundary transitions; reduce modulo 1 exactly
 transition=sorted(set(Fraction((2*i+1)*q,2*2400) % 1 for i in range(2400)))
 ms=[]
 for j in range(len(transition)):
  a=transition[j]; b=transition[(j+1)%len(transition)] + (1 if j==len(transition)-1 else 0)
  alpha=(a+b)/2 % 1
  # exact round-half-down of arbitrary rational point, no floating point rounding
  picked=tuple(sorted(int(math.floor(Fraction(2400,1)*(i+alpha)/q+Fraction(1,2))) % 2400 for i in range(q)))
  ms.append(picked)
 must(len(set(ms))==len(ms)=={16:150,32:75,64:75,128:75}[q],'EXACT_RATIONAL_MASK_UNIQUENESS')
 masks[q]=ms

max_mask_sha_error=0
for r in p2[['q','phase_id','mask_indices_sha256']].drop_duplicates().itertuples(index=False):
 idx=np.asarray(masks[int(r.q)][int(r.phase_id)],dtype='<i4')
 h=hashlib.sha256(idx.tobytes()).hexdigest()
 if h!=r.mask_indices_sha256:max_mask_sha_error+=1
must(max_mask_sha_error==0,'ALL_375_MASK_DIGESTS_RECALCULATED')
# independent check the source-sampled force and a stratified matrix of methods x tests x budgets
# Use ~27 x 4 budgets x one phase =648 estimates; extra distinct phases by rotating phase id.
max_work_err=0; verified_scores=0
for tid in range(14,41):
 x,f,c,W=sources[tid];u=np.arange(2400,dtype=float)
 for q in (16,32,64,128):
  for phase in [0, int({16:150,32:75,64:75,128:75}[q]//2),{16:149,32:74,64:74,128:74}[q]]:
   obs=np.asarray(masks[q][phase],dtype=int); yy=f[obs]
   for m in ('H1','H3','linear','pchip','cubic','nearest'):
    if m in ['H1','H3']:
     harm=1 if m=='H1' else 3
     Bs=np.array([np.ones(len(obs))]+[h for k in range(1,harm+1) for h in [np.cos(2*np.pi*k*obs/2400),np.sin(2*np.pi*k*obs/2400)]]).T
     Bf=np.array([np.ones(len(u))]+[h for k in range(1,harm+1) for h in [np.cos(2*np.pi*k*u/2400),np.sin(2*np.pi*k*u/2400)]]).T
     p=Bf@np.linalg.lstsq(Bs,yy,rcond=None)[0]
    elif m=='linear':
     p=np.interp(u,np.r_[obs[-1]-2400,obs,obs[0]+2400],np.r_[yy[-1],yy,yy[0]])
    elif m=='pchip':
     p=PchipInterpolator(np.r_[obs-2400,obs,obs+2400],np.tile(yy,3))(u)
    elif m=='cubic':
     cs=CubicSpline(np.r_[obs,obs[0]+2400],np.r_[yy,yy[0]],bc_type='periodic')
     p=cs(np.where(u<obs[0],u+2400,u))
    else:
     # independent brute-force actual circular nearest-distance, tie -> lowest stored numeric index
     circular=np.minimum(np.abs(u[:,None]-obs[None,:]),2400-np.abs(u[:,None]-obs[None,:]))
     p=yy[np.argmin(circular,axis=1)]
    what=float(np.dot(c,p))
    row=p2[(p2.test_id==tid)&(p2.q==q)&(p2.phase_id==phase)&(p2.method==m)]
    assert len(row)==1
    diff=abs(what-row.estimated_W_kNmm.iloc[0]);max_work_err=max(max_work_err,diff)
    verified_scores+=1
must(max_work_err<1e-8,'P2_STRATIFIED_ALTERNATE_IMPLEMENTATIONS')
# full ledger algebraic check, all 60750
recalc=(p2.estimated_W_kNmm-p2.source_W_kNmm).abs(); must(np.max(np.abs(recalc-p2.abs_error_kNmm))<1e-9,'P2_ALL_NATIVE_ERROR_IDENTITIES')
recalc_pct=100*recalc/p2.source_W_kNmm.abs();must(np.max(np.abs(recalc_pct-p2.relative_error_pct))<1e-9,'P2_ALL_RELATIVE_ERROR_IDENTITIES')
# per-mask winner/margin recomputation for all 10125 masks
x=p2.pivot_table(index=['test_id','q','phase_id'],columns='method',values='relative_error_pct',aggfunc='first')
ms=['H1','H3','linear','pchip','cubic','nearest'];ordidx=np.argsort(x[ms].to_numpy(),axis=1,kind='stable');z=x[ms].to_numpy()
winner=np.asarray(ms)[ordidx[:,0]]; margins=z[np.arange(len(x)),ordidx[:,1]]-z[np.arange(len(x)),ordidx[:,0]]
w=wins.set_index(['test_id','q','phase_id']).loc[x.index]
must(np.all(w.phase_winner.to_numpy()==winner),'P2_ALL_PHASE_WINNERS')
must(np.max(np.abs(w.first_second_margin_pp.to_numpy()-margins))<1e-11,'P2_ALL_PHASE_WINNER_MARGINS')
# all 108x6 aggregate worst phases from 60750 scores
xmax=p2.groupby(['test_id','q','method']).relative_error_pct.max().sort_index()
ymax=cagg.set_index(['test_id','q','method']).worst_phase_error_pct.sort_index()
must(np.max(np.abs(xmax-ymax))<1e-10,'P2_ALL_WORST_PHASE_SCORES')
RESULT.update({
 'verification_scope':'All 729 P1 records, all 60750 P2 score algebra, all 10125 winner/margins, independent reconstruction of 1944 source-phase-method work predictions (27x4x3x6), all 375 phase masks, all 27 source work references',
 'max_source_polygon_dot_gap':max_gap_polygon_dot,
 'max_P1_joint_score_error':max_p1_joint_delta,
 'max_P1_native_work_error':max_p1_absdelta,
 'max_P2_independently_reconstructed_work_error':max_work_err,
 'P2_independently_reconstructed_count':verified_scores,
 'all_checks_passed':True})
args.report.write_text(json.dumps(RESULT,indent=2)+'\n')
print('PASS',json.dumps(RESULT,indent=2))
